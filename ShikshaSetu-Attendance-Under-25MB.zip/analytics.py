import json
from datetime import datetime, timedelta
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from database import get_db_connection

# Color palette: Warm, inspiring educational theme
COLOR_PRESENT = '#10B981'    # Emerald Green
COLOR_ABSENT = '#EF4444'     # Coral Red
COLOR_PRIMARY = '#4F46E5'    # Indigo
COLOR_SECONDARY = '#06B6D4'  # Cyan
COLOR_WARNING = '#F59E0B'    # Amber
BG_COLOR = 'rgba(255, 255, 255, 0.95)'
FONT_FAMILY = 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'

def get_filtered_attendance_dataframe(time_filter='month', class_filter='all', custom_start=None, custom_end=None):
    """
    Fetches attendance records from SQLite and converts to a Pandas DataFrame with applied filters.
    """
    conn = get_db_connection()
    query = """
        SELECT a.attendance_id, a.student_id, a.student_name, a.date, a.time, 
               a.class, a.status, a.method, a.temperature,
               s.gender, s.roll_no
        FROM Attendance a
        LEFT JOIN Students s ON a.student_id = s.student_id
    """
    df = pd.read_sql_query(query, conn)
    conn.close()

    if df.empty:
        return df

    # Parse date column
    df['date_dt'] = pd.to_datetime(df['date'])
    today = datetime.now().date()

    # Time Filter
    if time_filter == 'today':
        df = df[df['date_dt'].dt.date == today]
    elif time_filter == 'week':
        week_ago = today - timedelta(days=7)
        df = df[df['date_dt'].dt.date >= week_ago]
    elif time_filter == 'month':
        month_ago = today - timedelta(days=30)
        df = df[df['date_dt'].dt.date >= month_ago]
    elif time_filter == 'custom' and custom_start and custom_end:
        start_d = datetime.strptime(custom_start, '%Y-%m-%d').date()
        end_d = datetime.strptime(custom_end, '%Y-%m-%d').date()
        df = df[(df['date_dt'].dt.date >= start_d) & (df['date_dt'].dt.date <= end_d)]

    # Class Filter
    if class_filter and class_filter.lower() != 'all':
        df = df[df['class'].str.lower() == class_filter.lower()]

    return df

def generate_pie_present_absent(df):
    """1. Pie Chart – Present vs Absent Students."""
    if df.empty or 'status' not in df:
        fig = go.Figure()
        fig.add_annotation(text="No data available for selected filter", showarrow=False, font=dict(size=14))
        return json.loads(fig.to_json())

    counts = df['status'].value_counts()
    present_cnt = int(counts.get('Present', 0))
    absent_cnt = int(counts.get('Absent', 0))

    fig = go.Figure(data=[
        go.Pie(
            labels=['Present', 'Absent'],
            values=[present_cnt, absent_cnt],
            marker=dict(colors=[COLOR_PRESENT, COLOR_ABSENT], line=dict(color='#FFFFFF', width=2)),
            textinfo='label+percent+value',
            hoverinfo='label+value+percent',
            hole=0.0,
            textfont=dict(family=FONT_FAMILY, size=14, color='#ffffff')
        )
    ])
    fig.update_layout(
        title=dict(text='<b>Present vs Absent Students</b>', font=dict(family=FONT_FAMILY, size=16, color='#1E293B')),
        font=dict(family=FONT_FAMILY),
        margin=dict(l=20, r=20, t=50, b=20),
        legend=dict(orientation="h", yanchor="bottom", y=-0.15, xanchor="center", x=0.5),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)'
    )
    return json.loads(fig.to_json())

def generate_bar_classwise(df):
    """2. Bar Chart – Class-wise Attendance."""
    if df.empty or 'class' not in df:
        fig = go.Figure()
        fig.add_annotation(text="No data available", showarrow=False)
        return json.loads(fig.to_json())

    class_group = df.groupby(['class', 'status']).size().unstack(fill_value=0)
    if 'Present' not in class_group.columns:
        class_group['Present'] = 0
    if 'Absent' not in class_group.columns:
        class_group['Absent'] = 0

    classes = list(class_group.index)
    p_vals = [int(v) for v in class_group['Present']]
    a_vals = [int(v) for v in class_group['Absent']]

    # Sort in natural order (Class 1 to 12)
    def natural_sort_key(item):
        c_name = item[0]
        try:
            parts = str(c_name).split('-')
            num = int(parts[0].replace('Class', '').strip())
            sec = parts[1] if len(parts) > 1 else ''
            return (num, sec)
        except Exception:
            return (999, str(c_name))

    combined = sorted(zip(classes, p_vals, a_vals), key=natural_sort_key)
    classes = [c[0] for c in combined]
    p_vals = [c[1] for c in combined]
    a_vals = [c[2] for c in combined]

    fig = go.Figure(data=[
        go.Bar(name='Present', x=classes, y=p_vals, marker_color=COLOR_PRESENT, text=p_vals, textposition='auto'),
        go.Bar(name='Absent', x=classes, y=a_vals, marker_color=COLOR_ABSENT, text=a_vals, textposition='auto')
    ])
    fig.update_layout(
        title=dict(text='<b>Class-wise Attendance Count</b>', font=dict(family=FONT_FAMILY, size=16, color='#1E293B')),
        barmode='group',
        font=dict(family=FONT_FAMILY),
        margin=dict(l=40, r=20, t=50, b=40),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        xaxis=dict(title='Class & Section', gridcolor='#F1F5F9'),
        yaxis=dict(title='Student Count', gridcolor='#F1F5F9'),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)'
    )
    return json.loads(fig.to_json())

def generate_line_daily_trends(df):
    """3. Line Chart – Daily Attendance Trends."""
    if df.empty or 'date' not in df:
        fig = go.Figure()
        fig.add_annotation(text="No data available", showarrow=False)
        return json.loads(fig.to_json())

    daily = df.groupby(['date', 'status']).size().unstack(fill_value=0)
    if 'Present' not in daily.columns:
        daily['Present'] = 0
    if 'Absent' not in daily.columns:
        daily['Absent'] = 0

    dates = list(daily.index)
    p_line = [int(v) for v in daily['Present']]
    a_line = [int(v) for v in daily['Absent']]

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=dates, y=p_line, mode='lines+markers', name='Present',
        line=dict(color=COLOR_PRESENT, width=3, shape='spline'),
        marker=dict(size=6, color=COLOR_PRESENT)
    ))
    fig.add_trace(go.Scatter(
        x=dates, y=a_line, mode='lines+markers', name='Absent',
        line=dict(color=COLOR_ABSENT, width=3, shape='spline'),
        marker=dict(size=6, color=COLOR_ABSENT)
    ))
    fig.update_layout(
        title=dict(text='<b>Daily Attendance Trends</b>', font=dict(family=FONT_FAMILY, size=16, color='#1E293B')),
        font=dict(family=FONT_FAMILY),
        margin=dict(l=40, r=20, t=50, b=40),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        xaxis=dict(title='Date', gridcolor='#F1F5F9'),
        yaxis=dict(title='Number of Students', gridcolor='#F1F5F9'),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)'
    )
    return json.loads(fig.to_json())

def generate_area_monthly_trends(df):
    """4. Area Chart – Monthly Attendance Trends."""
    if df.empty or 'date' not in df:
        fig = go.Figure()
        fig.add_annotation(text="No data available", showarrow=False)
        return json.loads(fig.to_json())

    # Daily percentage rate
    daily_total = df.groupby('date').size()
    daily_present = df[df['status'] == 'Present'].groupby('date').size()
    
    dates = list(daily_total.index)
    rates = []
    for d in dates:
        tot = daily_total.get(d, 0)
        p = daily_present.get(d, 0)
        rate = round((p / tot * 100), 1) if tot > 0 else 0
        rates.append(rate)

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=dates, y=rates,
        fill='tozeroy',
        mode='lines',
        line=dict(color='#6366F1', width=2),
        fillcolor='rgba(99, 102, 241, 0.25)',
        name='Attendance Rate %'
    ))
    fig.update_layout(
        title=dict(text='<b>Monthly Attendance Trend Rate (%)</b>', font=dict(family=FONT_FAMILY, size=16, color='#1E293B')),
        font=dict(family=FONT_FAMILY),
        margin=dict(l=40, r=20, t=50, b=40),
        xaxis=dict(title='Date', gridcolor='#F1F5F9'),
        yaxis=dict(title='Attendance Rate (%)', range=[0, 105], gridcolor='#F1F5F9'),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)'
    )
    return json.loads(fig.to_json())

def generate_donut_overall_rate(df):
    """5. Donut Chart – Overall Attendance Percentage."""
    if df.empty or 'status' not in df:
        fig = go.Figure()
        fig.add_annotation(text="No data available", showarrow=False)
        return json.loads(fig.to_json())

    counts = df['status'].value_counts()
    p_cnt = int(counts.get('Present', 0))
    a_cnt = int(counts.get('Absent', 0))
    total = p_cnt + a_cnt
    pct = round((p_cnt / total * 100), 1) if total > 0 else 0.0

    fig = go.Figure(data=[
        go.Pie(
            labels=['Present', 'Absent'],
            values=[p_cnt, a_cnt],
            hole=0.68,
            marker=dict(colors=[COLOR_PRESENT, '#E2E8F0'], line=dict(color='#FFFFFF', width=2)),
            textinfo='none',
            hoverinfo='label+value+percent'
        )
    ])
    fig.add_annotation(
        text=f"<b>{pct}%</b><br><span style='font-size:12px;color:#64748B;'>Overall</span>",
        x=0.5, y=0.5,
        font=dict(size=24, family=FONT_FAMILY, color='#0F172A'),
        showarrow=False
    )
    fig.update_layout(
        title=dict(text='<b>Overall Attendance Rate</b>', font=dict(family=FONT_FAMILY, size=16, color='#1E293B')),
        font=dict(family=FONT_FAMILY),
        margin=dict(l=20, r=20, t=50, b=20),
        legend=dict(orientation="h", yanchor="bottom", y=-0.15, xanchor="center", x=0.5),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)'
    )
    return json.loads(fig.to_json())

def generate_bar_studentwise(df):
    """6. Bar Chart – Student-wise Attendance Percentage."""
    if df.empty or 'student_name' not in df:
        fig = go.Figure()
        fig.add_annotation(text="No data available", showarrow=False)
        return json.loads(fig.to_json())

    student_total = df.groupby(['student_id', 'student_name']).size()
    student_present = df[df['status'] == 'Present'].groupby(['student_id', 'student_name']).size()

    names = []
    pcts = []
    colors = []

    # Sort by percentage ascending so low attendance students stand out on top!
    records = []
    for (sid, sname), tot in student_total.items():
        pres = student_present.get((sid, sname), 0)
        rate = round((pres / tot * 100), 1) if tot > 0 else 0.0
        records.append((sname, rate))

    records.sort(key=lambda r: r[1])
    # Limit to 15 students for clean readable bar chart
    sample_records = records[:15] if len(records) > 15 else records

    for sname, rate in sample_records:
        names.append(sname)
        pcts.append(rate)
        colors.append(COLOR_WARNING if rate < 75.0 else COLOR_PRIMARY)

    fig = go.Figure(data=[
        go.Bar(
            x=pcts, y=names, orientation='h',
            marker=dict(color=colors),
            text=[f"{p}%" for p in pcts],
            textposition='outside'
        )
    ])
    # Add 75% threshold guide line
    fig.add_vline(x=75, line_width=2, line_dash="dash", line_color="#DC2626", annotation_text="75% Min Target", annotation_position="top right")

    fig.update_layout(
        title=dict(text='<b>Student-wise Attendance % (Lowest Attendance Priority)</b>', font=dict(family=FONT_FAMILY, size=16, color='#1E293B')),
        font=dict(family=FONT_FAMILY),
        margin=dict(l=100, r=40, t=50, b=40),
        xaxis=dict(title='Attendance Rate (%)', range=[0, 110], gridcolor='#F1F5F9'),
        yaxis=dict(title='', autorange='reversed'),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)'
    )
    return json.loads(fig.to_json())

def get_all_charts(time_filter='month', class_filter='all', custom_start=None, custom_end=None):
    """Generates all 6 Plotly charts with the requested filters."""
    df = get_filtered_attendance_dataframe(time_filter, class_filter, custom_start, custom_end)
    return {
        'pie_present_absent': generate_pie_present_absent(df),
        'bar_classwise': generate_bar_classwise(df),
        'line_daily_trends': generate_line_daily_trends(df),
        'area_monthly_trends': generate_area_monthly_trends(df),
        'donut_overall': generate_donut_overall_rate(df),
        'bar_studentwise': generate_bar_studentwise(df)
    }
