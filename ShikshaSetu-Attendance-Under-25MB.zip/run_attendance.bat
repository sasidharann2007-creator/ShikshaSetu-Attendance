@echo off
setlocal
title ShikshaSetu - Smart Attendance
color 0A
cd /d "%~dp0"

echo ==================================================
echo   ShikshaSetu - Automated Attendance System
echo ==================================================
echo.

rem ---- 1. Python ----------------------------------------------------------
where python >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed or not on PATH.
    echo         Install Python 3.10+ from https://www.python.org/downloads/
    echo         and tick "Add Python to PATH", then run this file again.
    pause
    exit /b 1
)

rem ---- 2. Requirements (only installed if something is missing) -----------
python -c "import flask, numpy, PIL, plotly, requests, cv2" >nul 2>&1
if errorlevel 1 (
    echo [SETUP] Installing required packages, please wait...
    python -m pip install --upgrade pip >nul 2>&1
    python -m pip install -r requirements.txt
    if errorlevel 1 (
        echo [ERROR] Package installation failed. Check your internet connection.
        pause
        exit /b 1
    )
) else (
    echo [OK] All required packages are installed.
)

rem ---- 3. Face recognition models (downloaded once) -----------------------
if not exist "models\face_recognition_sface_2021dec.onnx" (
    echo [SETUP] Downloading face recognition models ^(about 40 MB, one time^)...
    python download_models.py
)
if not exist "models\face_detection_yunet_2023mar.onnx" python download_models.py

rem ---- 4. Join the ESP32-CAM Wi-Fi (ignored if not available) -------------
echo [WIFI] Connecting to ESP32-CAM network "ShikshaSetu-CAM"...
netsh wlan connect name=ShikshaSetu-CAM >nul 2>&1
timeout /t 5 /nobreak >nul

rem ---- 5. Dashboard server ------------------------------------------------
curl -s -o nul -m 3 http://127.0.0.1:5000/ >nul 2>&1
if errorlevel 1 (
    echo [START] Starting dashboard server...
    start "ShikshaSetu Dashboard" cmd /k "color 0A && cd /d "%~dp0" && python app.py"
    timeout /t 8 /nobreak >nul
) else (
    echo [OK] Dashboard is already running.
)

rem ---- 6. Open the dashboard in the browser -------------------------------
start "" http://127.0.0.1:5000/attendance/auto

rem ---- 7. ESP32-CAM bridge (keeps running in this window) -----------------
echo.
echo [START] ESP32-CAM bridge running. Close this window to stop it.
echo --------------------------------------------------
python -u hardware\esp32_bridge.py

echo.
echo Bridge stopped.
pause
