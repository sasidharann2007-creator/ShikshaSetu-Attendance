"""
Bridge between the ESP32-CAM (its own Wi-Fi access point) and the Flask dashboard.

1. Join the "ShikshaSetu-CAM" Wi-Fi network on this laptop.
2. Start the dashboard:  python app.py
3. Run this script:     python hardware/esp32_bridge.py

Loop: grab a frame from the camera -> send it to the dashboard for recognition ->
show the result on the LCD and sound the buzzer.
"""
import os
import sys
import time
from urllib.parse import urlencode

import requests

ESP32 = os.environ.get("ESP32_URL", "http://192.168.4.1")
SERVER = os.environ.get("DASHBOARD_URL", "http://127.0.0.1:5000")
API_KEY = os.environ.get("ESP32_API_KEY", "change-me-esp32-key")
DEVICE_ID = "ESP32-CAM-RURAL-01"

BEEP = {"success": "success", "duplicate": "duplicate", "unknown": "error", "error": "error",
        "enrolled": "success"}
HOLD = {"success": 2.5, "duplicate": 2.5, "unknown": 2.5, "error": 2.5, "enrolled": 2.5}
IDLE = ("Show your face", "to the camera")


def show(l1, l2, beep="none"):
    try:
        requests.get(f"{ESP32}/show?" + urlencode({"l1": l1, "l2": l2, "beep": beep}), timeout=3)
    except requests.RequestException as e:
        print(f"  (could not update LCD: {e})")


def main():
    print(f"ESP32-CAM: {ESP32}   Dashboard: {SERVER}")
    last_screen = None
    while True:
        try:
            frame = requests.get(f"{ESP32}/capture", timeout=5)
            frame.raise_for_status()
        except requests.RequestException as e:
            print(f"Camera unreachable ({e}). Is this laptop joined to the ShikshaSetu-CAM Wi-Fi?")
            time.sleep(2)
            continue

        try:
            r = requests.post(f"{SERVER}/api/esp32/attendance", data=frame.content, timeout=15,
                              headers={"Content-Type": "image/jpeg", "X-API-Key": API_KEY,
                                       "X-ESP32-Device-ID": DEVICE_ID})
            data = r.json()
        except (requests.RequestException, ValueError) as e:
            print(f"Dashboard error: {e}")
            show("Server offline", "Run app.py", "error")
            time.sleep(3)
            continue

        alert = data.get("alert", "error")
        l1, l2 = data.get("lcd1", ""), data.get("lcd2", "")
        if r.status_code == 401:
            l1, l2 = "Bad API key", "Check bridge"
        print(f"{time.strftime('%H:%M:%S')}  {alert:<10} {l1} | {l2}")

        if alert == "noface":
            if last_screen != "idle":
                show(*IDLE)
                last_screen = "idle"
            time.sleep(0.05)
        elif alert in ("confirming", "enrolling"):
            show(l1, l2)
            last_screen = alert
            time.sleep(0.15)
        else:
            show(l1, l2, BEEP.get(alert, "error"))
            time.sleep(HOLD.get(alert, 2.5))
            show(*IDLE)
            last_screen = "idle"


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(0)
