/*
 * ShikshaSetu - ESP32-CAM attendance terminal (access-point mode)
 * ---------------------------------------------------------------
 * The ESP32-CAM creates its own Wi-Fi network. Join it from the laptop, then run
 * `python hardware/esp32_bridge.py` - the bridge pulls frames from this board, sends
 * them to the Flask dashboard for face recognition, and pushes the result back here
 * to show on the LCD and sound the buzzer.
 *
 *   Wi-Fi name : ShikshaSetu-CAM        password : shiksha123
 *   Board IP   : 192.168.4.1
 *   GET /capture                    -> JPEG frame
 *   GET /show?l1=..&l2=..&beep=..   -> LCD text, beep = success|duplicate|error|none
 *   GET /ping                       -> "ok"
 *
 * Wiring: 5V->LCD VCC, GND->LCD GND & buzzer(-), GPIO15->LCD SDA, GPIO14->LCD SCL,
 *         GPIO13->buzzer(+)
 * Board : "AI Thinker ESP32-CAM"; libraries "LiquidCrystal I2C".
 */

#include "esp_camera.h"
#include <WiFi.h>
#include <WebServer.h>
#include <Wire.h>

const char* AP_SSID    = "ShikshaSetu-CAM";
const char* AP_PASS    = "shiksha123";          // at least 8 characters
const uint8_t LCD_ADDR = 0x27;                  // try 0x3F if the LCD stays blank

#define I2C_SDA     15
#define I2C_SCL     14
#define BUZZER_PIN  13

#define PWDN_GPIO_NUM  32
#define RESET_GPIO_NUM -1
#define XCLK_GPIO_NUM   0
#define SIOD_GPIO_NUM  26
#define SIOC_GPIO_NUM  27
#define Y9_GPIO_NUM    35
#define Y8_GPIO_NUM    34
#define Y7_GPIO_NUM    39
#define Y6_GPIO_NUM    36
#define Y5_GPIO_NUM    21
#define Y4_GPIO_NUM    19
#define Y3_GPIO_NUM    18
#define Y2_GPIO_NUM     5
#define VSYNC_GPIO_NUM 25
#define HREF_GPIO_NUM  23
#define PCLK_GPIO_NUM  22

// Minimal HD44780 driver for PCF8574 I2C backpacks. (The LiquidCrystal_I2C library calls
// Wire.begin() with default pins, which moves the bus off GPIO15/14, so we avoid it.)
class MiniLCD {
  uint8_t addr = 0x27, bl = 0x08;
  void expander(uint8_t d) { Wire.beginTransmission(addr); Wire.write(d | bl); Wire.endTransmission(); }
  void pulse(uint8_t d) { expander(d | 0x04); delayMicroseconds(1); expander(d & ~0x04); delayMicroseconds(60); }
  void write4(uint8_t nibble, bool rs) { uint8_t d = (nibble << 4) | (rs ? 1 : 0); expander(d); pulse(d); }
  void send(uint8_t v, bool rs) { write4(v >> 4, rs); write4(v & 0x0F, rs); }
 public:
  void begin(uint8_t a) {
    addr = a; delay(50); expander(0);
    write4(0x03, false); delay(5); write4(0x03, false); delay(5); write4(0x03, false); delay(1);
    write4(0x02, false);                 // 4-bit mode
    send(0x28, false);                   // 2 lines, 5x8 font
    send(0x0C, false);                   // display on, cursor off
    send(0x06, false);                   // entry mode
    clear();
  }
  void clear() { send(0x01, false); delay(3); }
  void setCursor(uint8_t col, uint8_t row) { send(0x80 | (col + (row ? 0x40 : 0)), false); }
  void print(const String& t) { for (size_t i = 0; i < t.length(); i++) send((uint8_t)t[i], true); }
  void backlight() { bl = 0x08; expander(0); }
};
MiniLCD lcd;
WebServer server(80);

void showLcd(const String& a, const String& b = "") {
  lcd.clear();
  lcd.setCursor(0, 0); lcd.print(a.substring(0, 16));
  lcd.setCursor(0, 1); lcd.print(b.substring(0, 16));
}

void beep(int ms) { digitalWrite(BUZZER_PIN, HIGH); delay(ms); digitalWrite(BUZZER_PIN, LOW); }
void beepSuccess()   { beep(120); delay(90); beep(250); }
void beepDuplicate() { for (int i = 0; i < 3; i++) { beep(80); delay(80); } }
void beepError()     { beep(700); }

bool g_hwJpeg = true;   // false when the sensor can't output JPEG (e.g. GC2145 modules)

bool tryInitCamera(pixformat_t fmt) {
  camera_config_t c;
  c.ledc_channel = LEDC_CHANNEL_0;  c.ledc_timer = LEDC_TIMER_0;
  c.pin_d0 = Y2_GPIO_NUM; c.pin_d1 = Y3_GPIO_NUM; c.pin_d2 = Y4_GPIO_NUM; c.pin_d3 = Y5_GPIO_NUM;
  c.pin_d4 = Y6_GPIO_NUM; c.pin_d5 = Y7_GPIO_NUM; c.pin_d6 = Y8_GPIO_NUM; c.pin_d7 = Y9_GPIO_NUM;
  c.pin_xclk = XCLK_GPIO_NUM; c.pin_pclk = PCLK_GPIO_NUM;
  c.pin_vsync = VSYNC_GPIO_NUM; c.pin_href = HREF_GPIO_NUM;
  c.pin_sccb_sda = SIOD_GPIO_NUM; c.pin_sccb_scl = SIOC_GPIO_NUM;
  c.pin_pwdn = PWDN_GPIO_NUM; c.pin_reset = RESET_GPIO_NUM;
  c.xclk_freq_hz = 20000000;
  c.pixel_format = fmt;
  c.grab_mode = CAMERA_GRAB_LATEST;
  c.fb_location = CAMERA_FB_IN_PSRAM;
  c.frame_size = (fmt == PIXFORMAT_JPEG) ? FRAMESIZE_VGA : FRAMESIZE_CIF;  // 400x296 raw = much faster
  c.jpeg_quality = 10;
  c.fb_count = (fmt == PIXFORMAT_JPEG) ? 2 : 1;
  if (!psramFound()) { c.frame_size = FRAMESIZE_QVGA; c.fb_location = CAMERA_FB_IN_DRAM; }
  return esp_camera_init(&c) == ESP_OK;
}

bool initCamera() {
  if (tryInitCamera(PIXFORMAT_JPEG)) { g_hwJpeg = true; return true; }
  esp_camera_deinit();
  Serial.println("Sensor has no JPEG output - using RGB565 + software JPEG");
  g_hwJpeg = false;
  return tryInitCamera(PIXFORMAT_RGB565);
}

void handleCapture() {
  camera_fb_t* fb = esp_camera_fb_get();
  if (!fb) { server.send(500, "text/plain", "camera capture failed"); return; }
  server.sendHeader("Cache-Control", "no-store");
  if (fb->format == PIXFORMAT_JPEG) {
    server.send_P(200, "image/jpeg", (const char*)fb->buf, fb->len);
  } else {
    uint8_t* jpg = nullptr; size_t jlen = 0;
    bool ok = frame2jpg(fb, 70, &jpg, &jlen);
    if (ok) server.send_P(200, "image/jpeg", (const char*)jpg, jlen);
    else    server.send(500, "text/plain", "jpeg conversion failed");
    if (jpg) free(jpg);
  }
  esp_camera_fb_return(fb);
}

void handleShow() {
  showLcd(server.arg("l1"), server.arg("l2"));
  String b = server.arg("beep");
  server.send(200, "text/plain", "ok");   // reply first so the bridge isn't kept waiting
  if (b == "success") beepSuccess();
  else if (b == "duplicate") beepDuplicate();
  else if (b == "error") beepError();
}

void setup() {
  Serial.begin(115200);
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  Wire.begin(I2C_SDA, I2C_SCL);
  // Scan the I2C bus and use whatever address the LCD backpack answers on.
  uint8_t found = 0;
  for (uint8_t a = 1; a < 127; a++) {
    Wire.beginTransmission(a);
    if (Wire.endTransmission() == 0) {
      Serial.printf("I2C device found at 0x%02X\n", a);
      if (!found) found = a;
    }
  }
  if (!found) Serial.println("NO I2C DEVICE FOUND - check SDA(GPIO15)/SCL(GPIO14)/VCC/GND wiring");
  lcd.begin(found ? found : LCD_ADDR);
  lcd.backlight();
  showLcd("ShikshaSetu", "Starting...");

  if (!initCamera()) {
    showLcd("Camera FAILED", "Check ribbon");
    while (true) { beepError(); delay(2000); }
  }

  {  // startup self-test: report what the sensor really delivers
    sensor_t* sen = esp_camera_sensor_get();
    Serial.printf("Sensor PID=0x%04x hwJpeg=%d psram=%d\n", sen ? sen->id.PID : 0, g_hwJpeg, psramFound());
    for (int i = 0; i < 3; i++) {
      camera_fb_t* fb = esp_camera_fb_get();
      if (fb) {
        Serial.printf("frame %d: %dx%d len=%u fmt=%d\n", i, fb->width, fb->height, (unsigned)fb->len, fb->format);
        esp_camera_fb_return(fb);
      } else {
        Serial.printf("frame %d: capture FAILED\n", i);
      }
    }
  }
  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID, AP_PASS);
  WiFi.setSleep(false);            // lower latency
  Serial.print("AP IP: "); Serial.println(WiFi.softAPIP());

  server.on("/capture", HTTP_GET, handleCapture);
  server.on("/show", HTTP_GET, handleShow);
  server.on("/ping", HTTP_GET, []() { server.send(200, "text/plain", "ok"); });
  server.begin();

  beep(100);
  showLcd("WiFi:ShikshaSetu", "192.168.4.1");
}

void loop() {
  server.handleClient();
}
