import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DATABASE_PATH = os.path.join(BASE_DIR, 'attendance_system.db')
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'static', 'uploads', 'students')
TEMP_CAPTURE_FOLDER = os.path.join(BASE_DIR, 'static', 'uploads', 'captures')
REPORTS_FOLDER = os.path.join(BASE_DIR, 'static', 'reports')

# Ensure necessary directories exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(TEMP_CAPTURE_FOLDER, exist_ok=True)
os.makedirs(REPORTS_FOLDER, exist_ok=True)

MODEL_DIR = os.path.join(BASE_DIR, 'models')
os.makedirs(MODEL_DIR, exist_ok=True)

# Cosine-similarity threshold for SFace (OpenCV recommends 0.363; higher = stricter)
FACE_MATCH_THRESHOLD = float(os.environ.get('FACE_MATCH_THRESHOLD', 0.40))

# Shared secret the ESP32-CAM sends in the X-API-Key header. Change it in both places.
ESP32_API_KEY = os.environ.get('ESP32_API_KEY', 'change-me-esp32-key')

SECRET_KEY =os.environ.get('SECRET_KEY', 'rural-school-smart-attendance-key-2026')
LOW_ATTENDANCE_THRESHOLD = 75.0  # Percentage below which alert is triggered


# Address of the ESP32-CAM on its own access point
ESP32_URL = os.environ.get('ESP32_URL', 'http://192.168.4.1')
