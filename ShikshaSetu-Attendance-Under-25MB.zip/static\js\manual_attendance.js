/**
 * Manual Attendance Register Client - ShikshaSetu
 */

let currentClassStudents = [];
let pendingEditRecord = null;

document.addEventListener('DOMContentLoaded', () => {
  loadClassRoster();

  // Change triggers
  document.getElementById('loadClassBtn')?.addEventListener('click', loadClassRoster);
  document.getElementById('manualClassSelect')?.addEventListener('change', loadClassRoster);
  document.getElementById('manualDateInput')?.addEventListener('change', loadClassRoster);

  // Bulk actions
  document.getElementById('markAllPresentBtn')?.addEventListener('click', () => setAllStatus('Present'));
  document.getElementById('markAllAbsentBtn')?.addEventListener('click', () => setAllStatus('Absent'));

  // Save full register
  document.getElementById('saveManualAttendanceBtn')?.addEventListener('click', saveManualAttendance);

  // Filter inside class
  document.getElementById('filterStudentInput')?.addEventListener('input', (e) => {
    const q = e.target.value.toLowerCase().trim();
    const rows = document.querySelectorAll('#manualTableBody tr[data-student-id]');
    rows.forEach(row => {
      const name = row.getAttribute('data-student-name').toLowerCase();
      const id = row.getAttribute('data-student-id').toLowerCase();
      if (!q || name.includes(q) || id.includes(q)) {
        row.style.display = '';
      } else {
        row.style.display = 'none';
      }
    });
  });

  // Confirm Authorized Edit
  document.getElementById('confirmAuthEditBtn')?.addEventListener('click', handleConfirmAuthEdit);
});

function loadClassRoster() {
  const classVal = document.getElementById('manualClassSelect').value;
  const parts = classVal.split('-');
  const className = parts[0];
  const section = parts[1] || 'A';
  const targetDate = document.getElementById('manualDateInput').value;

  const tbody = document.getElementById('manualTableBody');
  tbody.innerHTML = `
    <tr>
      <td colspan="6" class="text-center py-4 text-muted">
        <div class="spinner-border text-primary spinner-border-sm me-2" role="status"></div>
        Fetching class roster for ${classVal}...
      </td>
    </tr>
  `;

  document.getElementById('rosterTitle').textContent = `Attendance Roll Call: ${classVal} (${targetDate})`;

  fetch(`/api/attendance/manual/class_list?class_name=${encodeURIComponent(className)}&section=${encodeURIComponent(section)}&date=${targetDate}`)
    .then(r => r.json())
    .then(data => {
      if (data.success) {
        currentClassStudents = data.students;
        renderManualTable();
        updateSummaryStats();
      } else {
        tbody.innerHTML = `<tr><td colspan="6" class="text-center text-danger py-4">Failed to load class roster.</td></tr>`;
      }
    })
    .catch(err => {
      console.error(err);
      tbody.innerHTML = `<tr><td colspan="6" class="text-center text-danger py-4">Network error loading roster.</td></tr>`;
    });
}

function renderManualTable() {
  const tbody = document.getElementById('manualTableBody');
  if (!tbody) return;

  if (currentClassStudents.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="6" class="text-center py-4 text-muted">
          No students enrolled in this class.
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = currentClassStudents.map((s, idx) => `
    <tr data-student-id="${s.student_id}" data-student-name="${s.name}">
      <td><span class="badge bg-light text-dark border">#${s.roll_no}</span></td>
      <td>
        <div class="d-flex align-items-center gap-2">
          <img src="/static/uploads/students/${s.photo_path}" alt="${s.name}" class="student-avatar-img" onerror="this.src='/static/uploads/students/student_1.svg'">
          <div>
            <div class="fw-bold text-dark">${s.name}</div>
            <small class="text-muted">${s.student_id}</small>
          </div>
        </div>
      </td>
      <td>
        <div class="d-flex align-items-center gap-1">
          <span>${s.parent_phone}</span>
          <button class="btn btn-sm btn-link p-0 text-decoration-none" title="Send WhatsApp Message" style="color: #25D366; font-size: 1.1rem;" onclick="sendManualWhatsApp('${s.name}', '${s.student_id}', '${s.parent_phone}', '${s.status}')">
            <i class="bi bi-whatsapp"></i>
          </button>
        </div>
      </td>
      <td>
        ${s.is_marked ? `
          <span class="badge ${s.method === 'Automatic' ? 'badge-method-auto' : 'badge-method-manual'}">
            ${s.method} (${s.time})
          </span>
        ` : '<span class="text-muted small">Not saved yet</span>'}
      </td>
      <td class="text-center">
        <div class="btn-group btn-group-sm w-100" role="group">
          <button type="button" class="btn ${s.status === 'Present' ? 'btn-success' : 'btn-outline-success'}" onclick="setStudentStatus(${idx}, 'Present')">
            <i class="bi bi-check-lg me-1"></i>Present
          </button>
          <button type="button" class="btn ${s.status === 'Absent' ? 'btn-danger' : 'btn-outline-danger'}" onclick="setStudentStatus(${idx}, 'Absent')">
            <i class="bi bi-x-lg me-1"></i>Absent
          </button>
        </div>
      </td>
      <td class="text-end">
        ${s.attendance_id ? `
          <button class="btn btn-sm btn-outline-warning" title="Authorized Edit" onclick="openAuthEditModal(${idx})">
            <i class="bi bi-shield-lock me-1"></i>Edit
          </button>
        ` : `
          <span class="text-muted small">Direct save</span>
        `}
      </td>
    </tr>
  `).join('');
}

function setStudentStatus(index, newStatus) {
  if (currentClassStudents[index]) {
    currentClassStudents[index].status = newStatus;
    renderManualTable();
    updateSummaryStats();
  }
}

function setAllStatus(newStatus) {
  currentClassStudents.forEach(s => s.status = newStatus);
  renderManualTable();
  updateSummaryStats();
  showToast(`All students marked ${newStatus}`, 'info');
}

function updateSummaryStats() {
  const total = currentClassStudents.length;
  const present = currentClassStudents.filter(s => s.status === 'Present').length;
  const absent = total - present;
  const pct = total > 0 ? Math.round((present / total) * 100) : 0;

  document.getElementById('summaryTotalBadge').textContent = `Enrolled: ${total}`;
  document.getElementById('summaryPresentBadge').textContent = `Present: ${present}`;
  document.getElementById('summaryAbsentBadge').textContent = `Absent: ${absent}`;
  document.getElementById('summaryPctBadge').textContent = `Rate: ${pct}%`;
}

// Save Full Manual Attendance Register
function saveManualAttendance() {
  if (currentClassStudents.length === 0) {
    showToast("No students to save", "warning");
    return;
  }

  const btn = document.getElementById('saveManualAttendanceBtn');
  btn.disabled = true;
  btn.innerHTML = `<span class="spinner-border spinner-border-sm me-2"></span>Saving Register...`;

  const targetDate = document.getElementById('manualDateInput').value;
  const teacherName = document.getElementById('manualTeacherInput').value || 'Teacher';
  const fullClass = document.getElementById('manualClassSelect').value;

  const records = currentClassStudents.map(s => ({
    student_id: s.student_id,
    student_name: s.name,
    class: fullClass,
    status: s.status
  }));

  fetch('/api/attendance/manual/submit', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      date: targetDate,
      teacher_name: teacherName,
      records: records
    })
  })
    .then(r => r.json())
    .then(data => {
      btn.disabled = false;
      btn.innerHTML = `<i class="bi bi-cloud-arrow-up-fill fs-5"></i><span>Save Attendance Register</span>`;
      if (data.success) {
        buzzerSimulator.playSuccessChime();
        showToast(data.message, 'success');
        loadClassRoster();
      } else {
        showToast(data.message, 'error');
      }
    })
    .catch(err => {
      btn.disabled = false;
      btn.innerHTML = `<i class="bi bi-cloud-arrow-up-fill fs-5"></i><span>Save Attendance Register</span>`;
      showToast("Network error while saving attendance", 'error');
    });
}

// Authorized Edit Modal
function openAuthEditModal(index) {
  const student = currentClassStudents[index];
  if (!student) return;

  pendingEditRecord = student;
  document.getElementById('auth_edit_student').value = `${student.name} (${student.student_id})`;
  document.getElementById('auth_edit_status').value = student.status;
  document.getElementById('auth_edit_pin').value = '';

  const modal = new bootstrap.Modal(document.getElementById('authEditModal'));
  modal.show();
}

function handleConfirmAuthEdit() {
  if (!pendingEditRecord) return;

  const pin = document.getElementById('auth_edit_pin').value.trim();
  const newStatus = document.getElementById('auth_edit_status').value;
  const btn = document.getElementById('confirmAuthEditBtn');

  if (!pin) {
    showToast("Please enter teacher authorization PIN", "warning");
    return;
  }

  btn.disabled = true;
  btn.innerHTML = `<span class="spinner-border spinner-border-sm me-1"></span>Verifying...`;

  fetch(`/api/attendance/${pendingEditRecord.attendance_id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      status: newStatus,
      auth_pin: pin
    })
  })
    .then(r => r.json())
    .then(data => {
      btn.disabled = false;
      btn.innerHTML = `<i class="bi bi-check-circle-fill me-1"></i>Authorize & Update`;
      if (data.success) {
        showToast(data.message, 'success');
        bootstrap.Modal.getInstance(document.getElementById('authEditModal')).hide();
        loadClassRoster();
      } else {
        showToast(data.message, 'error');
      }
    })
    .catch(err => {
      btn.disabled = false;
      btn.innerHTML = `<i class="bi bi-check-circle-fill me-1"></i>Authorize & Update`;
      showToast("Authorization error", 'error');
    });
}


function sendManualWhatsApp(name, id, phone, status) {
  const cleanPhone = (phone || '').replace(/[^0-9]/g, '');
  const fullPhone = cleanPhone.length === 10 ? '91' + cleanPhone : cleanPhone;
  const today = document.getElementById('manualDateInput')?.value || new Date().toISOString().split('T')[0];
  const stText = status === 'Present' ? '✅ *PRESENT*' : (status === 'Absent' ? '❌ *ABSENT*' : `marked as *${status}*`);
  const msg = `Namaste Parent 🙏\n\n*Attendance Update - ShikshaSetu*\n\nStudent: *${name}* (ID: ${id})\nDate: *${today}*\nStatus: ${stText}\n\nGovt High School Vikas Kendra`;
  const url = `https://api.whatsapp.com/send?phone=${fullPhone}&text=${encodeURIComponent(msg)}`;
  window.open(url, '_blank');
}
