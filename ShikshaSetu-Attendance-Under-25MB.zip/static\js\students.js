/**
 * Student Management Client Script - ShikshaSetu
 */

let allStudents = [];

document.addEventListener('DOMContentLoaded', () => {
  loadStudents();

  // Search filter typing with debounce
  const searchInput = document.getElementById('searchInput');
  if (searchInput) {
    searchInput.addEventListener('input', debounce(() => {
      applyFilters();
    }, 250));
  }

  // Dropdown filters
  document.getElementById('classFilter')?.addEventListener('change', applyFilters);
  document.getElementById('genderFilter')?.addEventListener('change', applyFilters);

  // Reset Filters
  document.getElementById('resetFiltersBtn')?.addEventListener('click', () => {
    if (searchInput) searchInput.value = '';
    document.getElementById('classFilter').value = 'all';
    document.getElementById('genderFilter').value = 'all';
    renderTable(allStudents);
  });

  // Add Student Form Submit
  document.getElementById('addStudentForm')?.addEventListener('submit', handleAddStudent);
  // Edit Student Form Submit
  document.getElementById('editStudentForm')?.addEventListener('submit', handleUpdateStudent);
});

function debounce(func, wait) {
  let timeout;
  return function (...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(this, args), wait);
  };
}

function loadStudents() {
  fetch('/api/students')
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        allStudents = data.students;
        document.getElementById('studentTotalBadge').textContent = `${data.count} Students`;
        renderTable(allStudents);
      }
    })
    .catch(err => {
      console.error("Error loading students:", err);
      showToast("Failed to load students", "error");
    });
}

function applyFilters() {
  const q = document.getElementById('searchInput')?.value.toLowerCase().trim() || '';
  const selectedClass = document.getElementById('classFilter')?.value || 'all';
  const selectedGender = document.getElementById('genderFilter')?.value || 'all';

  const filtered = allStudents.filter(s => {
    const fullClass = `${s.class_name}-${s.section}`;
    const matchesQuery = !q || 
      s.name.toLowerCase().includes(q) || 
      s.student_id.toLowerCase().includes(q) || 
      s.parent_phone.includes(q);

    const matchesClass = (selectedClass === 'all') || (fullClass.toLowerCase() === selectedClass.toLowerCase());
    const matchesGender = (selectedGender === 'all') || (s.gender.toLowerCase() === selectedGender.toLowerCase());

    return matchesQuery && matchesClass && matchesGender;
  });

  document.getElementById('studentTotalBadge').textContent = `${filtered.length} Students`;
  renderTable(filtered);
}

function renderTable(students) {
  const tbody = document.getElementById('studentsTableBody');
  if (!tbody) return;

  if (students.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7" class="text-center py-4 text-muted">
          <i class="bi bi-search fs-2 d-block mb-2"></i>
          No matching students found for the current filter criteria.
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = students.map(s => `
    <tr>
      <td><span class="badge bg-light text-dark border">#${s.roll_no}</span></td>
      <td>
        <div class="d-flex align-items-center gap-2">
          <img src="/static/uploads/students/${s.photo_path}" alt="${s.name}" class="student-avatar-img" onerror="this.src='/static/uploads/students/student_1.svg'">
          <div>
            <div class="fw-bold text-dark">${s.name}</div>
            <small class="text-muted"><i class="bi bi-telephone me-1"></i>${s.parent_phone}</small>
          </div>
        </div>
      </td>
      <td><code>${s.student_id}</code></td>
      <td><span class="badge bg-primary bg-opacity-10 text-primary border border-primary border-opacity-25">${s.class_name}-${s.section}</span></td>
      <td>${s.gender}</td>
      <td>${s.parent_phone}</td>
      <td class="text-end">
        <div class="btn-group btn-group-sm">
          <button class="btn btn-outline-info" title="View Profile" onclick="viewStudentProfile('${s.student_id}')">
            <i class="bi bi-eye-fill"></i>
          </button>
          <button class="btn btn-outline-success" title="Send WhatsApp Message" style="color: #25D366; border-color: #25D366;" onmouseover="this.style.backgroundColor='#25D366';this.style.color='#fff';" onmouseout="this.style.backgroundColor='';this.style.color='#25D366';" onclick="sendStudentWhatsApp('${s.name}', '${s.student_id}', '${s.parent_phone}', '${s.class_name}-${s.section}')">
            <i class="bi bi-whatsapp"></i>
          </button>
          <button class="btn btn-outline-primary" title="Enroll face from ESP32-CAM" onclick="enrollFromDevice('${s.student_id}', '${s.name}')">
            <i class="bi bi-camera-fill"></i>
          </button>
          <button class="btn btn-outline-warning" title="Edit Student" onclick="openEditModal('${s.student_id}')">
            <i class="bi bi-pencil-fill"></i>
          </button>
          <button class="btn btn-outline-danger" title="Delete Student" onclick="deleteStudent('${s.student_id}', '${s.name}')">
            <i class="bi bi-trash-fill"></i>
          </button>
        </div>
      </td>
    </tr>
  `).join('');
}

// View Profile Modal
function viewStudentProfile(studentId) {
  const modalEl = document.getElementById('viewStudentModal');
  const modalBody = document.getElementById('viewStudentModalBody');
  const modal = new bootstrap.Modal(modalEl);
  
  modalBody.innerHTML = `
    <div class="text-center py-4">
      <div class="spinner-border text-primary" role="status"></div>
    </div>
  `;
  modal.show();

  fetch(`/api/students/${studentId}`)
    .then(r => r.json())
    .then(data => {
      if (!data.success) {
        modalBody.innerHTML = `<div class="alert alert-danger">${data.message}</div>`;
        return;
      }
      const s = data.student;
      const stats = data.stats;
      const recent = data.recent_history;
      const pct = stats.attendance_percentage;
      const pctBadgeClass = pct < 75 ? 'bg-danger' : (pct < 85 ? 'bg-warning text-dark' : 'bg-success');

      modalBody.innerHTML = `
        <div class="row g-4">
          <div class="col-12 col-md-4 text-center border-end">
            <img src="/static/uploads/students/${s.photo_path}" alt="${s.name}" class="student-avatar-lg mb-3" onerror="this.src='/static/uploads/students/student_1.svg'">
            <h5 class="fw-bold mb-1">${s.name}</h5>
            <div class="text-muted small mb-2">${s.student_id}</div>
            <span class="badge bg-primary px-3 py-1 mb-3">${s.class_name}-${s.section} (Roll #${s.roll_no})</span>
            
            <div class="card p-3 bg-light border-0 text-start mt-2">
              <div class="small text-muted mb-1">Gender: <strong>${s.gender}</strong></div>
              <div class="small text-muted mb-1">Parent Phone: <strong>+91 ${s.parent_phone}</strong></div>
              <div class="small text-muted">Enrollment: <strong>Active</strong></div>
            </div>
          </div>

          <div class="col-12 col-md-8">
            <h6 class="fw-bold text-dark mb-3"><i class="bi bi-bar-chart-line-fill text-primary me-2"></i>Attendance Statistics (Last 30 Days)</h6>
            
            <div class="row g-2 mb-3">
              <div class="col-4">
                <div class="border rounded p-2 text-center bg-light">
                  <div class="fw-bold fs-5 text-dark">${stats.total_days}</div>
                  <small class="text-muted" style="font-size: 0.75rem;">Total Days</small>
                </div>
              </div>
              <div class="col-4">
                <div class="border rounded p-2 text-center bg-success bg-opacity-10 border-success">
                  <div class="fw-bold fs-5 text-success">${stats.present_days}</div>
                  <small class="text-muted" style="font-size: 0.75rem;">Present</small>
                </div>
              </div>
              <div class="col-4">
                <div class="border rounded p-2 text-center bg-danger bg-opacity-10 border-danger">
                  <div class="fw-bold fs-5 text-danger">${stats.absent_days}</div>
                  <small class="text-muted" style="font-size: 0.75rem;">Absent</small>
                </div>
              </div>
            </div>

            <!-- Progress Bar -->
            <div class="mb-4">
              <div class="d-flex justify-content-between align-items-center mb-1">
                <span class="small fw-semibold">Attendance Rate</span>
                <span class="badge ${pctBadgeClass} fw-bold">${pct}%</span>
              </div>
              <div class="progress" style="height: 10px;">
                <div class="progress-bar ${pct < 75 ? 'bg-danger' : 'bg-success'}" role="progressbar" style="width: ${pct}%" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
              ${pct < 75 ? '<small class="text-danger fw-semibold d-block mt-1"><i class="bi bi-exclamation-triangle-fill me-1"></i>Low Attendance Alert (&lt; 75% target)</small>' : ''}
            </div>

            <!-- Recent logs -->
            <h6 class="fw-bold text-dark mb-2"><i class="bi bi-clock-history text-secondary me-2"></i>Recent Attendance Records</h6>
            <div class="table-responsive" style="max-height: 180px; overflow-y: auto;">
              <table class="table table-sm table-bordered" style="font-size: 0.8rem;">
                <thead class="table-light">
                  <tr>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Method</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  ${recent.map(r => `
                    <tr>
                      <td>${r.date}</td>
                      <td>${r.time}</td>
                      <td>${r.method}</td>
                      <td><span class="badge ${r.status === 'Present' ? 'bg-success' : 'bg-danger'}">${r.status}</span></td>
                    </tr>
                  `).join('') || '<tr><td colspan="4" class="text-center text-muted">No attendance history yet</td></tr>'}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      `;
    });
}

// Add Student Form Handler
function handleAddStudent(e) {
  e.preventDefault();
  const form = e.target;
  const formData = new FormData(form);
  const btn = document.getElementById('saveStudentBtn');
  btn.disabled = true;
  btn.innerHTML = `<span class="spinner-border spinner-border-sm me-1"></span>Saving...`;

  fetch('/api/students', {
    method: 'POST',
    body: formData
  })
    .then(r => r.json())
    .then(data => {
      btn.disabled = false;
      btn.innerHTML = `<i class="bi bi-check-lg me-1"></i>Save Student`;
      if (data.success) {
        showToast(data.message, 'success');
        form.reset();
        bootstrap.Modal.getInstance(document.getElementById('addStudentModal')).hide();
        loadStudents();
      } else {
        showToast(data.message, 'error');
      }
    })
    .catch(err => {
      btn.disabled = false;
      btn.innerHTML = `<i class="bi bi-check-lg me-1"></i>Save Student`;
      showToast("Network error while adding student", 'error');
    });
}

// Open Edit Modal
function openEditModal(studentId) {
  const student = allStudents.find(s => s.student_id === studentId);
  if (!student) return;

  document.getElementById('edit_student_id').value = student.student_id;
  document.getElementById('edit_name').value = student.name;
  document.getElementById('edit_class_name').value = student.class_name;
  document.getElementById('edit_section').value = student.section;
  document.getElementById('edit_roll_no').value = student.roll_no;
  document.getElementById('edit_gender').value = student.gender;
  document.getElementById('edit_parent_phone').value = student.parent_phone;

  const modal = new bootstrap.Modal(document.getElementById('editStudentModal'));
  modal.show();
}

// Handle Update Student
function handleUpdateStudent(e) {
  e.preventDefault();
  const form = e.target;
  const studentId = document.getElementById('edit_student_id').value;
  const formData = new FormData(form);
  const btn = document.getElementById('updateStudentBtn');
  btn.disabled = true;
  btn.innerHTML = `<span class="spinner-border spinner-border-sm me-1"></span>Updating...`;

  fetch(`/api/students/${studentId}`, {
    method: 'POST',
    body: formData
  })
    .then(r => r.json())
    .then(data => {
      btn.disabled = false;
      btn.innerHTML = `<i class="bi bi-save me-1"></i>Update Changes`;
      if (data.success) {
        showToast(data.message, 'success');
        bootstrap.Modal.getInstance(document.getElementById('editStudentModal')).hide();
        loadStudents();
      } else {
        showToast(data.message, 'error');
      }
    })
    .catch(err => {
      btn.disabled = false;
      btn.innerHTML = `<i class="bi bi-save me-1"></i>Update Changes`;
      showToast("Network error updating student", 'error');
    });
}

// Delete Student
function deleteStudent(studentId, studentName) {
  if (!confirm(`Are you sure you want to delete student ${studentName} (${studentId})? This action cannot be undone.`)) {
    return;
  }

  fetch(`/api/students/${studentId}`, {
    method: 'DELETE'
  })
    .then(r => r.json())
    .then(data => {
      if (data.success) {
        showToast(data.message, 'success');
        loadStudents();
      } else {
        showToast(data.message, 'error');
      }
    })
    .catch(err => {
      showToast("Network error deleting student", 'error');
    });
}


// Enroll a student's face using the ESP32-CAM (device takes the next clear face it sees)
function enrollFromDevice(studentId, studentName) {
  fetch(`/api/students/${studentId}/enroll-device`, { method: 'POST' })
    .then(r => r.json())
    .then(data => {
      if (!data.success) { showToast(data.message, 'error'); return; }
      showToast(data.message, 'success');
      const deadline = Date.now() + (data.seconds || 90) * 1000;
      const timer = setInterval(() => {
        fetch('/api/enroll-device/status').then(r => r.json()).then(st => {
          if (st.enrolled && st.enrolled.ok && st.enrolled.student_id === studentId) {
            clearInterval(timer);
            showToast(`Face enrolled for ${studentName} from ESP32-CAM.`, 'success');
            loadStudents();
          } else if (!st.pending || Date.now() > deadline) {
            clearInterval(timer);
            showToast('Camera enrollment timed out. Try again.', 'error');
          }
        }).catch(() => {});
      }, 2000);
    })
    .catch(() => showToast('Network error starting camera enrollment', 'error'));
}

function sendStudentWhatsApp(name, id, phone, className) {
  const cleanPhone = (phone || '').replace(/[^0-9]/g, '');
  const fullPhone = cleanPhone.length === 10 ? '91' + cleanPhone : cleanPhone;
  const msg = `Namaste Parent 🙏\n\nThis is regarding student *${name}* (ID: ${id}, Class: ${className}) from *Govt High School Vikas Kendra (ShikshaSetu)*.\n\nPlease feel free to contact us for any academic or attendance updates.\n\nThank you,\nSchool Administration`;
  const url = `https://api.whatsapp.com/send?phone=${fullPhone}&text=${encodeURIComponent(msg)}`;
  window.open(url, '_blank');
}
