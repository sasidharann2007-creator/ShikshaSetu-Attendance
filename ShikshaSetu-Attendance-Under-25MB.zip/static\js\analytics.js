/**
 * Plotly Attendance Analytics Client - ShikshaSetu
 */

document.addEventListener('DOMContentLoaded', () => {
  // Set default dates for custom picker
  const today = new Date().toISOString().split('T')[0];
  const thirtyDaysAgo = new Date(Date.now() - 30 * 86400000).toISOString().split('T')[0];
  document.getElementById('customStartDate').value = thirtyDaysAgo;
  document.getElementById('customEndDate').value = today;

  // Initial load
  loadAllAnalyticsCharts();

  // Radio button changes
  document.querySelectorAll('input[name="timeFilter"]').forEach(radio => {
    radio.addEventListener('change', (e) => {
      const customRow = document.getElementById('customDateRow');
      if (e.target.value === 'custom') {
        customRow.style.display = 'block';
      } else {
        customRow.style.display = 'none';
        loadAllAnalyticsCharts();
      }
    });
  });

  // Class filter change
  document.getElementById('analyticsClassFilter')?.addEventListener('change', loadAllAnalyticsCharts);

  // Apply custom date button
  document.getElementById('applyCustomDateBtn')?.addEventListener('click', loadAllAnalyticsCharts);
});

function loadAllAnalyticsCharts() {
  const timeFilter = document.querySelector('input[name="timeFilter"]:checked')?.value || 'month';
  const classFilter = document.getElementById('analyticsClassFilter')?.value || 'all';
  const startDate = document.getElementById('customStartDate')?.value || '';
  const endDate = document.getElementById('customEndDate')?.value || '';

  let url = `/api/analytics/charts?time_filter=${timeFilter}&class_filter=${encodeURIComponent(classFilter)}`;
  if (timeFilter === 'custom') {
    url += `&start_date=${startDate}&end_date=${endDate}`;
  }

  // Show spinners
  ['chartPiePresentAbsent', 'chartBarClasswise', 'chartLineDaily', 'chartAreaMonthly', 'chartDonutOverall', 'chartBarStudentwise'].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.innerHTML = `
        <div class="d-flex align-items-center justify-content-center h-100 py-5">
          <div class="spinner-border text-primary" role="status"></div>
        </div>
      `;
    }
  });

  fetch(url)
    .then(r => r.json())
    .then(res => {
      if (!res.success || !res.charts) {
        showToast("Failed to render charts", "error");
        return;
      }
      const c = res.charts;
      const config = { responsive: true, displayModeBar: true, displaylogo: false };

      // Clear loading spinners completely before rendering
      ['chartPiePresentAbsent', 'chartBarClasswise', 'chartLineDaily', 'chartAreaMonthly', 'chartDonutOverall', 'chartBarStudentwise'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.innerHTML = '';
      });

      // 1. Pie Chart
      Plotly.newPlot('chartPiePresentAbsent', c.pie_present_absent.data, c.pie_present_absent.layout, config);

      // 2. Bar Classwise
      Plotly.newPlot('chartBarClasswise', c.bar_classwise.data, c.bar_classwise.layout, config);

      // 3. Line Daily Trends
      Plotly.newPlot('chartLineDaily', c.line_daily_trends.data, c.line_daily_trends.layout, config);

      // 4. Area Monthly Trends
      Plotly.newPlot('chartAreaMonthly', c.area_monthly_trends.data, c.area_monthly_trends.layout, config);

      // 5. Donut Overall Percentage
      Plotly.newPlot('chartDonutOverall', c.donut_overall.data, c.donut_overall.layout, config);

      // 6. Bar Studentwise
      Plotly.newPlot('chartBarStudentwise', c.bar_studentwise.data, c.bar_studentwise.layout, config);

      showToast("Analytics charts refreshed successfully", "success");
    })
    .catch(err => {
      console.error("Analytics fetch error:", err);
      showToast("Network error loading analytics", "error");
    });
}

