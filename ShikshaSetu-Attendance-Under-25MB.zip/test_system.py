import json
from app import app
from database import get_db_connection

def run_tests():
    print("==================================================")
    print(" RUNNING AUTOMATED SUITE FOR SHIKSHASETU ATTENDANCE")
    print("==================================================")
    client = app.test_client()

    # 1. Test Dashboard Home
    resp = client.get('/')
    assert resp.status_code == 200, f"Dashboard failed with status {resp.status_code}"
    print(" [PASS] 1. Dashboard Home Page (GET /) -> 200 OK")

    # 2. Test Dashboard Summary Stats API
    resp = client.get('/api/dashboard/stats')
    assert resp.status_code == 200
    data = resp.get_json()
    assert data['total_students'] >= 30
    assert data['total_teachers'] >= 6
    assert data['total_classes'] >= 5
    assert 'attendance_percentage' in data
    print(f" [PASS] 2. Dashboard Stats API -> Students: {data['total_students']}, Teachers: {data['total_teachers']}, Classes: {data['total_classes']}, Rate: {data['attendance_percentage']}%")

    # 3. Test Student List API & Search
    resp = client.get('/api/students?class=Class%206-A')
    assert resp.status_code == 200
    stu_data = resp.get_json()
    assert stu_data['success'] is True
    print(f" [PASS] 3. Student Filter API (Class 6-A) -> {stu_data['count']} students found")

    # 4. Test Single Student Detail & Stats
    resp = client.get('/api/students/STU-601')
    assert resp.status_code == 200
    s_detail = resp.get_json()
    assert s_detail['success'] is True
    assert s_detail['student']['student_id'] == 'STU-601'
    print(f" [PASS] 4. Student Detail API -> {s_detail['student']['name']} (Attendance: {s_detail['stats']['attendance_percentage']}%)")

    # 5. Test Adding New Student
    new_stu = {
        'student_id': 'STU-TEST-99',
        'name': 'Kunal Sharma',
        'class_name': 'Class 8',
        'section': 'A',
        'roll_no': 99,
        'gender': 'Male',
        'parent_phone': '9876543210'
    }
    resp = client.post('/api/students', data=new_stu)
    assert resp.status_code in [200, 400] # Might already exist if rerun
    print(" [PASS] 5. Add Student API (POST /api/students) -> Verified")

    # 6. Test Analytics 6 Plotly Charts API
    resp = client.get('/api/analytics/charts?time_filter=month&class_filter=all')
    assert resp.status_code == 200
    charts_res = resp.get_json()
    assert charts_res['success'] is True
    charts = charts_res['charts']
    expected_charts = [
        'pie_present_absent',
        'bar_classwise',
        'line_daily_trends',
        'area_monthly_trends',
        'donut_overall',
        'bar_studentwise'
    ]
    for ch in expected_charts:
        assert ch in charts, f"Missing chart {ch}"
    print(f" [PASS] 6. Analytics Charts API -> All 6 Plotly interactive charts generated successfully: {list(charts.keys())}")

    # 7. Test Reports API
    resp = client.get('/api/reports/data?type=daily')
    assert resp.status_code == 200
    rep_data = resp.get_json()
    assert rep_data['success'] is True
    print(f" [PASS] 7. Daily Reports API -> {rep_data['count']} attendance records")

    # 8. Test CSV Export API
    resp = client.get('/api/reports/export/csv?type=daily')
    assert resp.status_code == 200
    assert 'text/csv' in resp.content_type
    print(f" [PASS] 8. CSV Export API -> Downloaded {len(resp.data)} bytes of CSV data")

    # 9. Test Low Attendance Alert (<75%)
    resp = client.get('/api/alerts/low-attendance')
    assert resp.status_code == 200
    alert_data = resp.get_json()
    assert alert_data['success'] is True
    assert alert_data['count'] > 0
    print(f" [PASS] 9. Low Attendance Alert API -> {alert_data['count']} students with attendance < 75% identified")

    # 10. Test Manual Attendance Submission
    manual_payload = {
        'date': '2026-11-11',
        'teacher_name': 'Test Teacher',
        'records': [
            {'student_id': 'STU-601', 'student_name': 'Aarav Kumar', 'class': 'Class 6-A', 'status': 'Present'},
            {'student_id': 'STU-602', 'student_name': 'Pooja Kumari', 'class': 'Class 6-A', 'status': 'Absent'}
        ]
    }
    resp = client.post('/api/attendance/manual/submit', json=manual_payload)
    assert resp.status_code == 200
    man_res = resp.get_json()
    assert man_res['success'] is True
    print(f" [PASS] 10. Manual Attendance Submit API -> {man_res['message']}")

    # 11. Test Duplicate Attendance Prevention (Automatic scan on already marked student)
    # Generate test image
    from PIL import Image
    import io, base64
    img = Image.new('RGB', (100, 100), color=(200, 150, 150))
    buf = io.BytesIO()
    img.save(buf, format='JPEG')
    b64_img = base64.b64encode(buf.getvalue()).decode('utf-8')

    auto_payload = {
        'image': b64_img,
        'session_id': 'test_sess',
        'verify_liveness': False, # Bypass blink in headless unit test
        'temperature': 98.4
    }
    resp = client.post('/api/attendance/recognize', json=auto_payload)
    assert resp.status_code == 200
    rec_res = resp.get_json()
    # Since STU-601 was already marked today in step 10, recognition should detect duplicate!
    assert rec_res.get('duplicate') is True or rec_res.get('success') is True
    if rec_res.get('duplicate'):
        print(f" [PASS] 11. Automatic Duplicate Prevention -> Correctly blocked duplicate: {rec_res['message']}")
    else:
        print(f" [PASS] 11. Automatic Recognition -> Attendance recorded: {rec_res['student_name']}")

    # 12. Test Hardware Status API
    resp = client.get('/api/hardware/status')
    assert resp.status_code == 200
    hw_data = resp.get_json()
    assert hw_data['device_id'] == 'ESP32-CAM-RURAL-01'
    print(f" [PASS] 12. Hardware Status API -> Device {hw_data['device_id']} connected: {hw_data['is_connected']}")

    print("\n==================================================")
    print(" ALL 12 VERIFICATION TESTS PASSED SUCCESSFULLY! ")
    print("==================================================")

if __name__ == '__main__':
    run_tests()

