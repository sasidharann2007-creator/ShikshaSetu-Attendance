import time
import random

class HardwareService:
    def __init__(self):
        self.device_id = "ESP32-CAM-RURAL-01"
        self.ip_address = "192.168.1.105"
        self.is_connected = True
        self.last_ping = time.time()
        self.green_led = False
        self.red_led = False
        self.flash_led = False
        self.buzzer_state = "IDLE"  # "IDLE", "CHIME_SUCCESS", "BEEP_WARNING", "ALARM_ERROR"
        self.last_temperature = 98.4
        self.last_attendance_event = None
        self.total_scans = 0

    def record_scan(self, student_id, student_name, success, alert_type="success", temp=None):
        self.last_ping = time.time()
        self.total_scans += 1
        if temp:
            self.last_temperature = float(temp)
        else:
            self.last_temperature = round(random.uniform(97.8, 98.6), 1)

        if success:
            self.green_led = True
            self.red_led = False
            self.buzzer_state = "CHIME_SUCCESS"
        else:
            self.green_led = False
            self.red_led = True
            if alert_type == "duplicate":
                self.buzzer_state = "BEEP_WARNING"
            elif alert_type == "spoof":
                self.buzzer_state = "ALARM_ERROR"
            else:
                self.buzzer_state = "ALARM_ERROR"

        self.last_attendance_event = {
            'student_id': student_id,
            'student_name': student_name,
            'success': success,
            'alert_type': alert_type,
            'temperature': self.last_temperature,
            'timestamp': time.strftime('%H:%M:%S')
        }

    def touch(self, ip=None, device_id=None):
        """Called on every request from the real device (heartbeat)."""
        self.last_ping = time.time()
        if ip:
            self.ip_address = ip
        if device_id:
            self.device_id = device_id

    def reset_indicators(self):
        self.green_led = False
        self.red_led = False
        self.buzzer_state = "IDLE"

    def get_status(self):
        time_since_ping = time.time() - self.last_ping
        is_online = time_since_ping < 300 # Online if pinged in last 5 minutes
        return {
            'device_id': self.device_id,
            'ip_address': self.ip_address,
            'is_connected': is_online,
            'last_ping_seconds_ago': int(time_since_ping),
            'green_led': self.green_led,
            'red_led': self.red_led,
            'flash_led': self.flash_led,
            'buzzer_state': self.buzzer_state,
            'temperature': self.last_temperature,
            'total_scans': self.total_scans,
            'last_event': self.last_attendance_event
        }

hardware_service = HardwareService()

