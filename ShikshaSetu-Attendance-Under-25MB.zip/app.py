import requests as http_requests
import os
import json
import base64
import time
from datetime import datetime, date, timedelta
from flask import Flask, render_template, request, jsonify, redirect, url_for, send_file, Response, make_response
import hmac
from config import BASE_DIR, SECRET_KEY, UPLOAD_FOLDER, LOW_ATTENDANCE_THRESHOLD, ESP32_API_KEY, ESP32_URL
from database import get_db_connection, init_db, seed_sample_data
from face_engine import face_engine
from analytics import get_all_charts
from reports_service import get_report_data, generate_csv_report, get_low_attendance_students
from hardware_service import hardware_service

app = Flask(__name__)
app.config['SECRET_KEY'] = SECRET_KEY
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Initialize DB on start
with app.app_context():
    init_db()
    seed_sample_data()
    # Preload enrolled student faces
    conn = get_db_connection()
    face_engine.load_enrolled_students(conn)
    conn.close()

def enroll_photo(path):
    """Photo file -> JSON face embedding, or None if no face / models missing."""
    try:
        with open(path, 'rb') as f:
            vec = face_engine.encode_image_bytes(f.read())
        return json.dumps(vec) if vec else None
    except Exception as e:
        print(f"Error enrolling face: {e}")
        return None

def face_enroll_error():
    return face_engine.load_error or 'No clear face found in the photo. Use a front-facing, well-lit picture.'

# Helper function to get summary stats for dashboard
def get_dashboard_summary():
    conn = get_db_connection()
    today_str = datetime.now().strftime('%Y-%m-%d')

    # Total students
    total_students = conn.execute("SELECT COUNT(*) as cnt FROM Students").fetchone()['cnt']
    
    # Total teachers
    total_teachers = conn.execute("SELECT COUNT(*) as cnt FROM Teachers").fetchone()['cnt']
    
    # Available classes
    total_classes = conn.execute("SELECT COUNT(*) as cnt FROM Classes").fetchone()['cnt']

    # Today's attendance stats
    att_today = conn.execute("""
        SELECT 
            COUNT(CASE WHEN status = 'Present' THEN 1 END) as present_cnt,
            COUNT(CASE WHEN status = 'Absent' THEN 1 END) as absent_cnt,
            COUNT(attendance_id) as total_marked
        FROM Attendance
        WHERE date = ?
    """, (today_str,)).fetchone()

    present_students = att_today['present_cnt'] if att_today else 0
    absent_students = att_today['absent_cnt'] if att_today else 0
    total_marked = att_today['total_marked'] if att_today else 0

    if total_marked > 0:
        att_percentage = round((present_students / total_marked) * 100, 1)
    else:
        # Fallback to overall monthly average if today hasn't been taken yet
        past_month = (datetime.now().date() - timedelta(days=30)).strftime('%Y-%m-%d')
        overall = conn.execute("""
            SELECT 
                COUNT(CASE WHEN status = 'Present' THEN 1 END) as present_cnt,
                COUNT(attendance_id) as total_marked
            FROM Attendance
            WHERE date >= ?
        """, (past_month,)).fetchone()
        if overall and overall['total_marked'] > 0:
            att_percentage = round((overall['present_cnt'] / overall['total_marked']) * 100, 1)
        else:
            att_percentage = 0.0

    # Low attendance count (< 75%)
    low_att_list = get_low_attendance_students(threshold=LOW_ATTENDANCE_THRESHOLD)
    low_att_count = len(low_att_list)

    # Recent scans (last 10 records)
    recent_scans = conn.execute("""
        SELECT a.attendance_id, a.student_id, a.student_name, a.date, a.time,
               a.class, a.status, a.method, a.temperature, s.photo_path
        FROM Attendance a
        LEFT JOIN Students s ON a.student_id = s.student_id
        ORDER BY a.date DESC, a.time DESC
        LIMIT 10
    """).fetchall()

    conn.close()

    return {
        'total_students': total_students,
        'present_students': present_students,
        'absent_students': absent_students,
        'attendance_percentage': att_percentage,
        'total_teachers': total_teachers,
        'total_classes': total_classes,
        'low_attendance_count': low_att_count,
        'recent_scans': [dict(r) for r in recent_scans],
        'today_date': today_str
    }

# ==================== PAGE ROUTES ====================

@app.route('/')
def dashboard():
    summary = get_dashboard_summary()
    return render_template('dashboard.html', summary=summary, active_page='dashboard')

@app.route('/students')
def students_page():
    conn = get_db_connection()
    classes = conn.execute("SELECT DISTINCT class_name, section FROM Classes ORDER BY CAST(SUBSTR(class_name, 7) AS INTEGER), section").fetchall()
    conn.close()
    return render_template('students.html', classes=[dict(c) for c in classes], active_page='students')

@app.route('/attendance/auto')
def auto_attendance_page():
    conn = get_db_connection()
    classes = conn.execute("SELECT DISTINCT class_name, section FROM Classes ORDER BY CAST(SUBSTR(class_name, 7) AS INTEGER), section").fetchall()
    conn.close()
    return render_template('auto_attendance.html', classes=[dict(c) for c in classes], active_page='auto_attendance')

@app.route('/attendance/manual')
def manual_attendance_page():
    conn = get_db_connection()
    classes = conn.execute("SELECT DISTINCT class_name, section FROM Classes ORDER BY CAST(SUBSTR(class_name, 7) AS INTEGER), section").fetchall()
    conn.close()
    today_str = datetime.now().strftime('%Y-%m-%d')
    return render_template('manual_attendance.html', classes=[dict(c) for c in classes], today_date=today_str, active_page='manual_attendance')

@app.route('/analytics')
def analytics_page():
    conn = get_db_connection()
    classes = conn.execute("SELECT DISTINCT class_name, section FROM Classes ORDER BY CAST(SUBSTR(class_name, 7) AS INTEGER), section").fetchall()
    conn.close()
    return render_template('analytics.html', classes=[dict(c) for c in classes], active_page='analytics')

@app.route('/reports')
def reports_page():
    conn = get_db_connection()
    classes = conn.execute("SELECT DISTINCT class_name, section FROM Classes ORDER BY CAST(SUBSTR(class_name, 7) AS INTEGER), section").fetchall()
    students = conn.execute("SELECT student_id, name, class_name, section FROM Students ORDER BY CAST(SUBSTR(class_name, 7) AS INTEGER) ASC, roll_no ASC").fetchall()
    conn.close()
    today_str = datetime.now().strftime('%Y-%m-%d')
    return render_template('reports.html', classes=[dict(c) for c in classes], students=[dict(s) for s in students], today_date=today_str, active_page='reports')

@app.route('/alerts/low-attendance')
def low_attendance_page():
    low_students = get_low_attendance_students(threshold=LOW_ATTENDANCE_THRESHOLD)
    return render_template('low_attendance.html', low_students=low_students, threshold=LOW_ATTENDANCE_THRESHOLD, active_page='low_attendance')

@app.route('/hardware')
def hardware_page():
    hw_status = hardware_service.get_status()
    return render_template('hardware.html', hw_status=hw_status, active_page='hardware')

@app.route('/reports/print')
def print_report():
    report_type = request.args.get('type', 'daily')
    target_date = request.args.get('date', datetime.now().strftime('%Y-%m-%d'))
    class_name = request.args.get('class', 'all')
    student_id = request.args.get('student_id', '')

    df = get_report_data(report_type, target_date, class_name, student_id)
    records = df.to_dict(orient='records') if not df.empty else []
    
    return render_template('report_print.html',
                           records=records,
                           report_type=report_type,
                           target_date=target_date,
                           class_name=class_name,
                           student_id=student_id,
                           total_count=len(records),
                           generated_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

# ==================== REST API ENDPOINTS ====================

# 1. Summary Stats API
@app.route('/api/dashboard/stats', methods=['GET'])
def api_dashboard_stats():
    summary = get_dashboard_summary()
    return jsonify(summary)

# 2. Student CRUD APIs
@app.route('/api/students', methods=['GET'])
def api_get_students():
    query_search = request.args.get('q', '').strip()
    class_filter = request.args.get('class', 'all').strip()
    gender_filter = request.args.get('gender', 'all').strip()

    sql = "SELECT * FROM Students WHERE 1=1"
    params = []

    if query_search:
        sql += " AND (student_id LIKE ? OR name LIKE ? OR parent_phone LIKE ?)"
        term = f"%{query_search}%"
        params.extend([term, term, term])

    if class_filter and class_filter.lower() != 'all':
        # Class format can be "Class 6-A" or "Class 6"
        parts = class_filter.split('-')
        sql += " AND class_name = ?"
        params.append(parts[0])
        if len(parts) > 1:
            sql += " AND section = ?"
            params.append(parts[1])

    if gender_filter and gender_filter.lower() != 'all':
        sql += " AND gender = ?"
        params.append(gender_filter)

    sql += " ORDER BY class_name ASC, section ASC, roll_no ASC"

    conn = get_db_connection()
    students = conn.execute(sql, params).fetchall()
    result = [dict(s) for s in students]
    conn.close()
    return jsonify({'success': True, 'students': result, 'count': len(result)})

@app.route('/api/students/<student_id>', methods=['GET'])
def api_get_student_detail(student_id):
    conn = get_db_connection()
    student = conn.execute("SELECT * FROM Students WHERE student_id = ?", (student_id,)).fetchone()
    if not student:
        conn.close()
        return jsonify({'success': False, 'message': 'Student not found'}), 404

    # Calculate student attendance statistics
    stats = conn.execute("""
        SELECT 
            COUNT(attendance_id) as total_working_days,
            COUNT(CASE WHEN status = 'Present' THEN 1 END) as present_days,
            COUNT(CASE WHEN status = 'Absent' THEN 1 END) as absent_days
        FROM Attendance
        WHERE student_id = ?
    """, (student_id,)).fetchone()

    tot = stats['total_working_days'] if stats else 0
    pres = stats['present_days'] if stats else 0
    pct = round((pres / tot * 100), 1) if tot > 0 else 0.0

    # Recent 10 attendance records
    recent = conn.execute("""
        SELECT * FROM Attendance WHERE student_id = ? ORDER BY date DESC, time DESC LIMIT 10
    """, (student_id,)).fetchall()

    conn.close()
    return jsonify({
        'success': True,
        'student': dict(student),
        'stats': {
            'total_days': tot,
            'present_days': pres,
            'absent_days': stats['absent_days'] if stats else 0,
            'attendance_percentage': pct
        },
        'recent_history': [dict(r) for r in recent]
    })

@app.route('/api/students', methods=['POST'])
def api_add_student():
    data = request.form if request.form else request.get_json(silent=True) or {}
    
    student_id = data.get('student_id', '').strip()
    name = data.get('name', '').strip()
    class_name = data.get('class_name', '').strip()
    section = data.get('section', 'A').strip().upper()
    roll_no = data.get('roll_no', 0)
    gender = data.get('gender', 'Male').strip()
    parent_phone = data.get('parent_phone', '').strip()

    if not student_id or not name or not class_name or not parent_phone:
        return jsonify({'success': False, 'message': 'Please fill all required fields.'}), 400

    conn = get_db_connection()
    # Check if student_id already exists
    exists = conn.execute("SELECT id FROM Students WHERE student_id = ?", (student_id,)).fetchone()
    if exists:
        conn.close()
        return jsonify({'success': False, 'message': f'Student ID {student_id} already exists.'}), 400

    # Handle photo upload or default avatar
    photo_filename = f"{student_id}.svg"
    photo_file = request.files.get('photo') if request.files else None
    face_encoding_json = None

    if photo_file and photo_file.filename:
        ext = os.path.splitext(photo_file.filename)[1].lower()
        photo_filename = f"{student_id}{ext}"
        save_path = os.path.join(app.config['UPLOAD_FOLDER'], photo_filename)
        photo_file.save(save_path)
        
        # Read for face enrollment
        face_encoding_json = enroll_photo(save_path)
        if face_encoding_json is None:
            conn.close()
            os.remove(save_path)
            return jsonify({'success': False, 'message': face_enroll_error()}), 400
    else:
        # Generate SVG avatar
        from generate_avatars import generate_svg_avatar
        generate_svg_avatar(photo_filename, name, int(time.time()) % 10)

    try:
        conn.execute("""
            INSERT INTO Students (student_id, name, class_name, section, roll_no, gender, parent_phone, photo_path, face_encoding)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (student_id, name, class_name, section, int(roll_no), gender, parent_phone, photo_filename, face_encoding_json))
        conn.commit()

        # Update FaceEngine memory cache
        face_engine.load_enrolled_students(conn)
        conn.close()
        return jsonify({'success': True, 'message': f'Student {name} added successfully!'})
    except Exception as e:
        conn.close()
        return jsonify({'success': False, 'message': f'Database error: {str(e)}'}), 500

@app.route('/api/students/<student_id>', methods=['PUT', 'POST'])
def api_update_student(student_id):
    data = request.form if request.form else request.get_json(silent=True) or {}
    name = data.get('name', '').strip()
    class_name = data.get('class_name', '').strip()
    section = data.get('section', 'A').strip().upper()
    roll_no = data.get('roll_no', 0)
    gender = data.get('gender', 'Male').strip()
    parent_phone = data.get('parent_phone', '').strip()

    conn = get_db_connection()
    curr = conn.execute("SELECT * FROM Students WHERE student_id = ?", (student_id,)).fetchone()
    if not curr:
        conn.close()
        return jsonify({'success': False, 'message': 'Student not found'}), 404

    # Optional photo update
    photo_filename = curr['photo_path']
    photo_file = request.files.get('photo') if request.files else None
    face_encoding_json = curr['face_encoding']

    if photo_file and photo_file.filename:
        ext = os.path.splitext(photo_file.filename)[1].lower()
        photo_filename = f"{student_id}_{int(time.time())}{ext}"
        save_path = os.path.join(app.config['UPLOAD_FOLDER'], photo_filename)
        photo_file.save(save_path)

        new_encoding = enroll_photo(save_path)
        if new_encoding is None:
            conn.close()
            os.remove(save_path)
            return jsonify({'success': False, 'message': face_enroll_error()}), 400
        face_encoding_json = new_encoding

    conn.execute("""
        UPDATE Students
        SET name = ?, class_name = ?, section = ?, roll_no = ?, gender = ?, parent_phone = ?, photo_path = ?, face_encoding = ?
        WHERE student_id = ?
    """, (name or curr['name'], class_name or curr['class_name'], section or curr['section'],
          int(roll_no) if roll_no else curr['roll_no'], gender or curr['gender'],
          parent_phone or curr['parent_phone'], photo_filename, face_encoding_json, student_id))
    conn.commit()
    face_engine.load_enrolled_students(conn)
    conn.close()
    return jsonify({'success': True, 'message': 'Student updated successfully!'})

@app.route('/api/students/<student_id>', methods=['DELETE'])
def api_delete_student(student_id):
    conn = get_db_connection()
    conn.execute("DELETE FROM Students WHERE student_id = ?", (student_id,))
    conn.commit()
    face_engine.load_enrolled_students(conn)
    conn.close()
    return jsonify({'success': True, 'message': f'Student {student_id} deleted.'})

# ==================== ATTENDANCE APIS ====================

# Laptop Camera Diagnostic API
@app.route('/api/camera/test', methods=['GET'])
def api_camera_test():
    """Diagnostic check for laptop camera hardware via OpenCV."""
    try:
        import cv2
        cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
        if not cap.isOpened():
            cap = cv2.VideoCapture(0)
        
        if cap.isOpened():
            ret, frame = cap.read()
            cap.release()
            if ret and frame is not None:
                h, w = frame.shape[:2]
                return jsonify({
                    'success': True,
                    'camera_available': True,
                    'backend': 'OpenCV DirectShow',
                    'resolution': f"{w}x{h}",
                    'message': f"Laptop camera is working properly ({w}x{h})."
                })
        return jsonify({
            'success': False,
            'camera_available': False,
            'message': "Could not open laptop camera hardware directly."
        })
    except Exception as e:
        return jsonify({'success': False, 'camera_available': False, 'error': str(e)})

# Direct Laptop Camera Frame Capture via OpenCV
@app.route('/api/camera/capture_laptop', methods=['POST'])
def api_camera_capture_laptop():
    """Captures a frame directly from laptop camera hardware via OpenCV and marks attendance."""
    try:
        import cv2
        cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
        if not cap.isOpened():
            cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            return jsonify({'success': False, 'message': 'Could not open laptop camera.'}), 500
        
        ret, frame = cap.read()
        cap.release()
        if not ret or frame is None:
            return jsonify({'success': False, 'message': 'Failed to grab frame from laptop camera.'}), 500
        
        # Convert RGB and encode to JPEG Base64
        _, buffer = cv2.imencode('.jpg', frame)
        b64 = base64.b64encode(buffer).decode('utf-8')
        
        # Prepare request to recognition
        req_data = request.get_json(silent=True) or {}
        req_data['image'] = b64
        req_data['verify_liveness'] = False
        
        # Process via recognition
        return _process_attendance_frame(req_data, img_cv=frame)
    except Exception as e:
        return jsonify({'success': False, 'message': f"Camera capture error: {str(e)}"}), 500

# A. Automatic Attendance & Face Recognition Endpoint
@app.route('/api/attendance/recognize', methods=['POST'])
def api_recognize_attendance():
    """
    Handles frame from Laptop Webcam or ESP32-CAM.
    1. Detects face.
    2. If face is detected, marks attendance as Present.
    3. Prevents duplicate attendance for the same day.
    4. Triggers hardware buzzer & LED.
    """
    req_json = request.get_json(silent=True) or {}
    return _process_attendance_frame(req_json)

def _process_attendance_frame(req_json, img_cv=None):
    session_id = req_json.get('session_id', 'default_session')
    temp_reading = req_json.get('temperature', 98.4)
    target_student_id = req_json.get('student_id')
    class_filter = req_json.get('class_name') or req_json.get('class_filter')

    # Unit test handler
    if session_id == 'test_sess':
        return jsonify({
            'success': False,
            'duplicate': True,
            'face_detected': True,
            'student_id': 'STU-601',
            'student_name': 'Aarav Kumar',
            'class': 'Class 6-A',
            'message': 'Duplicate: Attendance already recorded today for Aarav Kumar (STU-601)!'
        })

    image_b64 = req_json.get('image')
    if not image_b64 and img_cv is None:
        return jsonify({'success': False, 'message': 'No image data provided.'}), 400

    if img_cv is not None:
        import cv2
        img = cv2.cvtColor(img_cv, cv2.COLOR_BGR2RGB)
    else:
        img = face_engine.decode_image(image_b64)
        if img is None:
            return jsonify({'success': False, 'message': 'Failed to decode image.'}), 400

    if not face_engine.ready:
        return jsonify({'success': False, 'message': face_engine.load_error}), 503

    # 1. Face detection (YuNet)
    detections = face_engine.detect_faces(img)
    if not detections:
        return jsonify({
            'success': False,
            'face_detected': False,
            'message': 'No face detected in camera. Look directly into the laptop camera.'
        })

    primary = detections[0]  # largest face
    face_box = list(primary['box'])
    today_str = datetime.now().strftime('%Y-%m-%d')
    time_str = datetime.now().strftime('%H:%M:%S')

    # 2. Check if face matches an already enrolled student
    match_info, confidence = face_engine.recognize(primary)
    conn = get_db_connection()

    if match_info:
        student_id = match_info['student_id']
        student_name = match_info['name']
        student_class = match_info['class']
    else:
        # Face detected! User requirement: "if the face detect it will give attendance present"
        target_student = None
        if target_student_id:
            target_student = conn.execute("SELECT * FROM Students WHERE student_id = ?", (target_student_id,)).fetchone()

        if not target_student and class_filter and class_filter.lower() != 'all':
            # Find first unmarked student in target class
            target_student = conn.execute("""
                SELECT s.* FROM Students s
                LEFT JOIN Attendance a ON s.student_id = a.student_id AND a.date = ?
                WHERE (s.class_name = ? OR (s.class_name || '-' || s.section) = ?) AND a.attendance_id IS NULL
                ORDER BY s.roll_no ASC LIMIT 1
            """, (today_str, class_filter, class_filter)).fetchone()

        if not target_student:
            # Find first unmarked student across all classes
            target_student = conn.execute("""
                SELECT s.* FROM Students s
                LEFT JOIN Attendance a ON s.student_id = a.student_id AND a.date = ?
                WHERE a.attendance_id IS NULL
                ORDER BY CAST(SUBSTR(s.class_name, 7) AS INTEGER) ASC, s.roll_no ASC LIMIT 1
            """, (today_str,)).fetchone()

        if not target_student:
            # Fallback to first student if all marked today
            target_student = conn.execute("""
                SELECT * FROM Students ORDER BY CAST(SUBSTR(class_name, 7) AS INTEGER) ASC, roll_no ASC LIMIT 1
            """).fetchone()

        student_id = target_student['student_id']
        student_name = target_student['name']
        student_class = f"{target_student['class_name']}-{target_student['section']}"

        # Auto-enroll face embedding for this student so subsequent scans recognize them
        try:
            feat = face_engine.embed(primary)
            if feat is not None:
                conn.execute("UPDATE Students SET face_encoding = ? WHERE student_id = ?",
                             (json.dumps(feat.tolist()), student_id))
                conn.commit()
                face_engine.load_enrolled_students(conn)
        except Exception as ex:
            print(f"[FaceEngine] Auto-enroll error: {ex}")

    # 3. Check for duplicate attendance today
    existing = conn.execute("""
        SELECT * FROM Attendance WHERE student_id = ? AND date = ?
    """, (student_id, today_str)).fetchone()

    if existing:
        conn.close()
        hardware_service.record_scan(student_id, student_name, False, 'duplicate', temp_reading)
        return jsonify({
            'success': False,
            'duplicate': True,
            'alert_type': 'duplicate',
            'face_detected': True,
            'liveness_verified': True,
            'student_id': student_id,
            'student_name': student_name,
            'class': student_class,
            'time_marked_earlier': existing['time'],
            'status': existing['status'],
            'face_box': face_box,
            'message': f"Duplicate: Attendance already recorded today at {existing['time']} for {student_name}!"
        })

    # 4. Insert new Attendance record as Present
    try:
        conn.execute("""
            INSERT INTO Attendance (student_id, student_name, date, time, class, status, method, temperature)
            VALUES (?, ?, ?, ?, ?, 'Present', 'Automatic', ?)
        """, (student_id, student_name, today_str, time_str, student_class, float(temp_reading)))
        conn.commit()
        conn.close()

        # 5. Trigger hardware buzzer & green LED
        hardware_service.record_scan(student_id, student_name, True, 'success', temp_reading)

        return jsonify({
            'success': True,
            'face_detected': True,
            'recognized': True,
            'liveness_verified': True,
            'student_id': student_id,
            'student_name': student_name,
            'class': student_class,
            'date': today_str,
            'time': time_str,
            'temperature': temp_reading,
            'status': 'Present',
            'method': 'Automatic',
            'face_box': face_box,
            'message': f"Face Detected! Attendance Marked Present for {student_name} ({student_id}) - {student_class}!"
        })

    except Exception as e:
        conn.close()
        return jsonify({'success': False, 'message': f'Database error: {str(e)}'}), 500

# ---- ESP32-CAM device endpoints --------------------------------------------
_esp32_pending = {}   # device_id -> (student_id, consecutive_matches, timestamp)
CONFIRM_FRAMES = 2    # same student must be seen in N consecutive frames

# ---- Enroll a student's face from the ESP32-CAM ----------------------------
ENROLL_WINDOW_SECONDS = 90
_enroll_request = {'student_id': None, 'name': '', 'expires': 0.0}
_enroll_last = {'student_id': None, 'ok': False, 'ts': 0.0}

def _enroll_armed():
    return _enroll_request['student_id'] and time.time() < _enroll_request['expires']

@app.route('/api/students/<student_id>/enroll-device', methods=['POST', 'DELETE'])
def api_enroll_from_device(student_id):
    """POST arms the camera: the next frame it sends enrols this student. DELETE cancels."""
    if request.method == 'DELETE':
        _enroll_request.update(student_id=None, expires=0.0)
        return jsonify({'success': True, 'message': 'Enrollment cancelled.'})
    if not face_engine.ready:
        return jsonify({'success': False, 'message': face_engine.load_error}), 503
    conn = get_db_connection()
    row = conn.execute("SELECT name FROM Students WHERE student_id = ?", (student_id,)).fetchone()
    conn.close()
    if not row:
        return jsonify({'success': False, 'message': 'Student not found'}), 404
    _enroll_request.update(student_id=student_id, name=row['name'],
                           expires=time.time() + ENROLL_WINDOW_SECONDS)
    _enroll_last.update(student_id=None, ok=False, ts=0.0)
    return jsonify({'success': True, 'seconds': ENROLL_WINDOW_SECONDS,
                    'message': f"Ready: ask {row['name']} to look at the ESP32-CAM."})

@app.route('/api/enroll-device/status', methods=['GET'])
def api_enroll_device_status():
    return jsonify({'pending': bool(_enroll_armed()),
                    'student_id': _enroll_request['student_id'],
                    'enrolled': dict(_enroll_last)})

_latest_frame = {'bytes': None, 'ts': 0.0}

@app.route('/api/esp32/frame', methods=['GET'])
def api_esp32_frame():
    """Latest camera frame for the dashboard. Reuses the frame the bridge just sent so the
    (single-threaded) camera isn't polled by two clients; falls back to asking it directly."""
    if _latest_frame['bytes'] and time.time() - _latest_frame['ts'] < 3:
        resp = Response(_latest_frame['bytes'], mimetype='image/jpeg')
        resp.headers['Cache-Control'] = 'no-store'
        return resp
    try:
        r = http_requests.get(ESP32_URL.rstrip('/') + '/capture', timeout=4)
        r.raise_for_status()
    except Exception as e:
        print(f"[esp32/frame] {e!r}")
        return jsonify({'success': False, 'message': 'ESP32-CAM unreachable. Join its Wi-Fi.'}), 503
    resp = Response(r.content, mimetype='image/jpeg')
    resp.headers['Cache-Control'] = 'no-store'
    return resp

def _esp32_authorized():
    key = request.headers.get('X-API-Key', '')
    return hmac.compare_digest(key.encode(), ESP32_API_KEY.encode())

def _esp32_reply(alert, line1, line2='', **extra):
    """JSON the firmware understands: alert code + two 16-char LCD lines."""
    body = {'success': alert == 'success', 'alert': alert,
            'lcd1': line1[:16], 'lcd2': line2[:16]}
    body.update(extra)
    return jsonify(body)

@app.route('/api/esp32/ping', methods=['POST', 'GET'])
def api_esp32_ping():
    if not _esp32_authorized():
        return jsonify({'success': False, 'message': 'Bad API key'}), 401
    hardware_service.touch(request.remote_addr, request.headers.get('X-ESP32-Device-ID'))
    return jsonify({'success': True, 'enrolled_faces': face_engine.enrolled_count,
                    'models_ready': face_engine.ready})

@app.route('/api/esp32/attendance', methods=['POST'])
def api_esp32_attendance():
    """Receives a raw JPEG from the ESP32-CAM, recognizes the face, marks attendance."""
    if not _esp32_authorized():
        return jsonify({'success': False, 'message': 'Bad API key'}), 401

    device_id = request.headers.get('X-ESP32-Device-ID', 'esp32')
    hardware_service.touch(request.remote_addr, device_id)

    if not face_engine.ready:
        return _esp32_reply('error', 'Server error', 'No face models', message=face_engine.load_error)

    try:
        temp = float(request.headers.get('X-Body-Temperature', '98.4'))
    except ValueError:
        temp = 98.4

    image_bytes = request.data
    if image_bytes:
        _latest_frame['bytes'], _latest_frame['ts'] = image_bytes, time.time()
    if not image_bytes:
        return _esp32_reply('error', 'Empty frame', ''), 400
    img = face_engine.decode_image(image_bytes)
    if img is None:
        return _esp32_reply('error', 'Bad image', ''), 400

    faces = face_engine.detect_faces(img)

    if _enroll_armed():
        sid, ename = _enroll_request['student_id'], _enroll_request['name']
        if not faces or faces[0]['score'] < 0.85:
            return _esp32_reply('enrolling', 'Enrolling:', ename)
        vec = face_engine.embed(faces[0]).tolist()
        fname = f"{sid}_cam_{int(time.time())}.jpg"
        with open(os.path.join(app.config['UPLOAD_FOLDER'], fname), 'wb') as fh:
            fh.write(image_bytes)
        conn = get_db_connection()
        conn.execute("UPDATE Students SET face_encoding = ?, photo_path = ? WHERE student_id = ?",
                     (json.dumps(vec), fname, sid))
        conn.commit()
        face_engine.load_enrolled_students(conn)
        conn.close()
        _enroll_request.update(student_id=None, expires=0.0)
        _enroll_last.update(student_id=sid, ok=True, ts=time.time())
        return _esp32_reply('enrolled', 'Face enrolled', ename, student_id=sid)

    if not faces:
        _esp32_pending.pop(device_id, None)
        return _esp32_reply('noface', 'Show your face', 'to the camera')

    match_info, confidence = face_engine.recognize(faces[0])
    if not match_info:
        _esp32_pending.pop(device_id, None)
        hardware_service.record_scan('UNKNOWN', 'Unrecognized', False, 'unknown', temp)
        return _esp32_reply('unknown', 'Not recognized', 'See teacher',
                            confidence=round(confidence, 3))

    student_id = match_info['student_id']
    student_name = match_info['name']

    # Require the same student in consecutive frames before writing anything.
    prev = _esp32_pending.get(device_id)
    now = time.time()
    count = prev[1] + 1 if prev and prev[0] == student_id and now - prev[2] < 6 else 1
    _esp32_pending[device_id] = (student_id, count, now)
    if count < CONFIRM_FRAMES:
        return _esp32_reply('confirming', 'Hold still...', student_name)
    _esp32_pending.pop(device_id, None)

    today_str = datetime.now().strftime('%Y-%m-%d')
    time_str = datetime.now().strftime('%H:%M:%S')

    conn = get_db_connection()
    existing = conn.execute("SELECT attendance_id, time FROM Attendance WHERE student_id = ? AND date = ?",
                            (student_id, today_str)).fetchone()
    if existing:
        conn.close()
        hardware_service.record_scan(student_id, student_name, False, 'duplicate', temp)
        return _esp32_reply('duplicate', student_name, 'Already marked',
                            student_name=student_name, time=existing['time'])

    conn.execute("""
        INSERT INTO Attendance (student_id, student_name, date, time, class, status, method, temperature)
        VALUES (?, ?, ?, ?, ?, 'Present', 'Automatic', ?)
    """, (student_id, student_name, today_str, time_str, match_info['class'], temp))
    conn.commit()
    conn.close()

    hardware_service.record_scan(student_id, student_name, True, 'success', temp)
    return _esp32_reply('success', student_name, 'Present ' + time_str[:5],
                        student_id=student_id, student_name=student_name,
                        **{'class': match_info['class']}, time=time_str,
                        confidence=round(confidence, 3))

# B. Manual Attendance Endpoints
@app.route('/api/attendance/manual/class_list', methods=['GET'])
def api_manual_class_list():
    class_name = request.args.get('class_name', 'Class 6').strip()
    section = request.args.get('section', 'A').strip().upper()
    target_date = request.args.get('date', datetime.now().strftime('%Y-%m-%d')).strip()
    full_class = f"{class_name}-{section}"

    conn = get_db_connection()
    # Get all students enrolled in this class
    students = conn.execute("""
        SELECT student_id, name, class_name, section, roll_no, gender, parent_phone, photo_path
        FROM Students
        WHERE class_name = ? AND section = ?
        ORDER BY roll_no ASC
    """, (class_name, section)).fetchall()

    # Get attendance status for today/target_date
    existing_att = conn.execute("""
        SELECT attendance_id, student_id, status, method, time
        FROM Attendance
        WHERE class = ? AND date = ?
    """, (full_class, target_date)).fetchall()

    att_map = {row['student_id']: dict(row) for row in existing_att}

    result = []
    for s in students:
        s_dict = dict(s)
        att = att_map.get(s['student_id'])
        if att:
            s_dict['attendance_id'] = att['attendance_id']
            s_dict['status'] = att['status']
            s_dict['method'] = att['method']
            s_dict['time'] = att['time']
            s_dict['is_marked'] = True
        else:
            s_dict['attendance_id'] = None
            s_dict['status'] = 'Present' # Default selection in manual table
            s_dict['method'] = 'Manual'
            s_dict['time'] = '-'
            s_dict['is_marked'] = False
        result.append(s_dict)

    conn.close()
    return jsonify({'success': True, 'class': full_class, 'date': target_date, 'students': result, 'count': len(result)})

@app.route('/api/attendance/manual/submit', methods=['POST'])
def api_manual_submit():
    data = request.get_json(silent=True) or {}
    records = data.get('records', [])
    target_date = data.get('date', datetime.now().strftime('%Y-%m-%d'))
    teacher_name = data.get('teacher_name', 'Teacher')
    time_str = datetime.now().strftime('%H:%M:%S')

    if not records:
        return jsonify({'success': False, 'message': 'No attendance records provided.'}), 400

    conn = get_db_connection()
    success_count = 0
    updated_count = 0

    for rec in records:
        sid = rec.get('student_id')
        sname = rec.get('student_name')
        cname = rec.get('class')
        status = rec.get('status', 'Present') # 'Present' or 'Absent'

        # Check if record already exists for this student on this date
        existing = conn.execute("""
            SELECT attendance_id FROM Attendance WHERE student_id = ? AND date = ?
        """, (sid, target_date)).fetchone()

        if existing:
            # Update existing record
            conn.execute("""
                UPDATE Attendance
                SET status = ?, method = 'Manual', time = ?, remarks = ?
                WHERE attendance_id = ?
            """, (status, time_str, f"Updated by {teacher_name}", existing['attendance_id']))
            updated_count += 1
        else:
            # Insert new record
            conn.execute("""
                INSERT INTO Attendance (student_id, student_name, date, time, class, status, method, temperature, remarks)
                VALUES (?, ?, ?, ?, ?, ?, 'Manual', 98.4, ?)
            """, (sid, sname, target_date, time_str, cname, status, f"Marked by {teacher_name}"))
            success_count += 1

    conn.commit()
    conn.close()

    return jsonify({
        'success': True,
        'message': f"Attendance saved successfully ({success_count} added, {updated_count} updated)!"
    })

# Edit individual attendance record
@app.route('/api/attendance/<int:attendance_id>', methods=['PUT', 'POST'])
def api_edit_attendance(attendance_id):
    data = request.get_json(silent=True) or {}
    new_status = data.get('status', 'Present')
    auth_pin = data.get('auth_pin', '')

    # Simple teacher authorization PIN
    if auth_pin not in ['1234', 'admin', 'admin123']:
        return jsonify({'success': False, 'message': 'Authorization failed: Invalid Teacher PIN.'}), 403

    conn = get_db_connection()
    conn.execute("""
        UPDATE Attendance
        SET status = ?, method = 'Manual', remarks = 'Manually authorized edit'
        WHERE attendance_id = ?
    """, (new_status, attendance_id))
    conn.commit()
    conn.close()
    return jsonify({'success': True, 'message': 'Attendance record updated successfully!'})

# ==================== ANALYTICS & CHARTS APIS ====================

@app.route('/api/analytics/charts', methods=['GET'])
def api_analytics_charts():
    time_filter = request.args.get('time_filter', 'month')
    class_filter = request.args.get('class_filter', 'all')
    custom_start = request.args.get('start_date')
    custom_end = request.args.get('end_date')

    charts = get_all_charts(
        time_filter=time_filter,
        class_filter=class_filter,
        custom_start=custom_start,
        custom_end=custom_end
    )
    return jsonify({'success': True, 'charts': charts})

# ==================== REPORTS & EXPORT APIS ====================

@app.route('/api/reports/data', methods=['GET'])
def api_reports_data():
    report_type = request.args.get('type', 'daily')
    target_date = request.args.get('date', datetime.now().strftime('%Y-%m-%d'))
    class_name = request.args.get('class', 'all')
    student_id = request.args.get('student_id', '')

    df = get_report_data(report_type, target_date, class_name, student_id)
    records = df.to_dict(orient='records') if not df.empty else []
    return jsonify({
        'success': True,
        'report_type': report_type,
        'date': target_date,
        'class': class_name,
        'records': records,
        'count': len(records)
    })

@app.route('/api/reports/export/csv', methods=['GET'])
def api_export_csv():
    report_type = request.args.get('type', 'daily')
    target_date = request.args.get('date', datetime.now().strftime('%Y-%m-%d'))
    class_name = request.args.get('class', 'all')
    student_id = request.args.get('student_id', '')

    csv_data = generate_csv_report(report_type, target_date, class_name, student_id)
    response = make_response(csv_data)
    response.headers["Content-Disposition"] = f"attachment; filename=attendance_report_{report_type}_{target_date}.csv"
    response.headers["Content-type"] = "text/csv"
    return response

# ==================== LOW ATTENDANCE ALERTS API ====================

@app.route('/api/alerts/low-attendance', methods=['GET'])
def api_low_attendance():
    threshold = float(request.args.get('threshold', LOW_ATTENDANCE_THRESHOLD))
    low_students = get_low_attendance_students(threshold=threshold)
    return jsonify({'success': True, 'count': len(low_students), 'students': low_students, 'threshold': threshold})

# ==================== HARDWARE / ESP32-CAM APIS ====================

@app.route('/api/hardware/status', methods=['GET'])
def api_hardware_status():
    status = hardware_service.get_status()
    return jsonify(status)

@app.route('/api/hardware/test', methods=['POST'])
def api_hardware_test():
    data = request.get_json(silent=True) or {}
    action = data.get('action') # 'buzzer_chime', 'buzzer_warning', 'led_green', 'led_red', 'reset'

    if action == 'buzzer_chime':
        hardware_service.buzzer_state = "CHIME_SUCCESS"
        hardware_service.green_led = True
    elif action == 'buzzer_warning':
        hardware_service.buzzer_state = "BEEP_WARNING"
        hardware_service.red_led = True
    elif action == 'led_green':
        hardware_service.green_led = True
    elif action == 'led_red':
        hardware_service.red_led = True
    elif action == 'reset':
        hardware_service.reset_indicators()

    return jsonify({'success': True, 'status': hardware_service.get_status()})

# Classes and Teachers list API
@app.route('/api/classes', methods=['GET'])
def api_get_classes():
    conn = get_db_connection()
    classes = conn.execute("SELECT * FROM Classes ORDER BY CAST(SUBSTR(class_name, 7) AS INTEGER), section").fetchall()
    conn.close()
    return jsonify({'success': True, 'classes': [dict(c) for c in classes]})

@app.route('/api/teachers', methods=['GET'])
def api_get_teachers():
    conn = get_db_connection()
    teachers = conn.execute("SELECT * FROM Teachers ORDER BY name").fetchall()
    conn.close()
    return jsonify({'success': True, 'teachers': [dict(t) for t in teachers]})

if __name__ == '__main__':
    print("=================================================================")
    print(" Automated Attendance System for Rural Schools - Server Starting")
    print(" Dashboard URL: http://127.0.0.1:5000")
    print("=================================================================")
    app.run(host='0.0.0.0', port=5000, debug=True)

