"""
Face detection + recognition using OpenCV's bundled DNN face models:
  * YuNet  - face detector (returns box, 5 landmarks, score)
  * SFace  - face recognizer (128-d embedding, cosine similarity)

Model files live in ./models (run `python download_models.py` once to fetch them).
There is NO fallback matching: if the models are missing, or no enrolled face is
similar enough, the result is "unknown".
"""
import base64
import io
import json
import os
import time

import cv2
import numpy as np
from PIL import Image

from config import MODEL_DIR, FACE_MATCH_THRESHOLD

DETECTOR_MODEL = os.path.join(MODEL_DIR, 'face_detection_yunet_2023mar.onnx')
RECOGNIZER_MODEL = os.path.join(MODEL_DIR, 'face_recognition_sface_2021dec.onnx')
EMBED_DIM = 128


class FaceEngine:
    def __init__(self):
        self._enrolled_faces = {}     # student_id -> 128-d unit vector
        self._student_info = {}       # student_id -> dict
        self._liveness_sessions = {}  # session_id -> state
        self._detector = None
        self._recognizer = None
        self.load_error = None
        self._load_models()

    # ------------------------------------------------------------------ models
    def _load_models(self):
        missing = [p for p in (DETECTOR_MODEL, RECOGNIZER_MODEL) if not os.path.exists(p)]
        if missing:
            self.load_error = ("Face models not found. Run `python download_models.py` "
                               "(missing: " + ", ".join(os.path.basename(m) for m in missing) + ")")
            print(f"[FaceEngine] {self.load_error}")
            return
        try:
            self._detector = cv2.FaceDetectorYN.create(DETECTOR_MODEL, "", (320, 320), 0.7, 0.3, 5000)
            self._recognizer = cv2.FaceRecognizerSF.create(RECOGNIZER_MODEL, "")
            print("[FaceEngine] YuNet + SFace models loaded.")
        except Exception as e:  # pragma: no cover
            self.load_error = f"Could not load face models: {e}"
            print(f"[FaceEngine] {self.load_error}")

    @property
    def ready(self):
        return self._detector is not None and self._recognizer is not None

    # --------------------------------------------------------------- enrolment
    def load_enrolled_students(self, db_conn):
        """Rebuild the in-memory cache from the database (drops deleted students)."""
        self._enrolled_faces = {}
        self._student_info = {}
        rows = db_conn.execute(
            "SELECT student_id, name, class_name, section, photo_path, face_encoding FROM Students"
        ).fetchall()
        for r in rows:
            sid = r['student_id']
            self._student_info[sid] = {
                'student_id': sid,
                'name': r['name'],
                'class': f"{r['class_name']}-{r['section']}",
                'photo_path': r['photo_path'],
            }
            if r['face_encoding']:
                try:
                    vec = np.array(json.loads(r['face_encoding']), dtype=np.float32)
                except Exception:
                    continue
                # Ignore encodings produced by the old (non-neural) engine.
                if vec.shape == (EMBED_DIM,):
                    self._enrolled_faces[sid] = vec

    @property
    def enrolled_count(self):
        return len(self._enrolled_faces)

    # ------------------------------------------------------------------ images
    def decode_image(self, image_data):
        """bytes / base64 / data-URL -> RGB numpy array (H, W, 3), or None."""
        try:
            if isinstance(image_data, str):
                if ',' in image_data:
                    image_data = image_data.split(',', 1)[1]
                image_data = base64.b64decode(image_data)
            if not isinstance(image_data, (bytes, bytearray)):
                return None
            return np.array(Image.open(io.BytesIO(image_data)).convert('RGB'))
        except Exception as e:
            print(f"[FaceEngine] Decode error: {e}")
            return None

    # --------------------------------------------------------------- detection
    def detect_faces(self, img_rgb):
        """Returns a list of faces, largest first. Each: box, score, landmarks, row."""
        if not self.ready or img_rgb is None:
            return []
        h, w = img_rgb.shape[:2]
        if h < 40 or w < 40:
            return []
        bgr = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2BGR)
        self._detector.setInputSize((w, h))
        _, rows = self._detector.detect(bgr)
        if rows is None:
            return []
        faces = []
        for row in rows:
            x, y, fw, fh = [int(v) for v in row[:4]]
            faces.append({
                'box': (x, y, fw, fh),
                'score': float(row[14]),
                'landmarks': row[4:14].reshape(5, 2),  # r-eye, l-eye, nose, r-mouth, l-mouth
                'row': row,
                '_bgr': bgr,
            })
        faces.sort(key=lambda f: f['box'][2] * f['box'][3], reverse=True)
        return faces

    def embed(self, face):
        """128-d unit-length embedding for a detected face."""
        aligned = self._recognizer.alignCrop(face['_bgr'], face['row'])
        feat = self._recognizer.feature(aligned).flatten().astype(np.float32)
        n = np.linalg.norm(feat)
        return feat / n if n > 0 else feat

    def encode_image_bytes(self, image_bytes):
        """Enrolment helper: photo bytes -> embedding list (JSON-ready) or None."""
        faces = self.detect_faces(self.decode_image(image_bytes))
        if not faces:
            return None
        return self.embed(faces[0]).tolist()

    # ------------------------------------------------------------- recognition
    def recognize(self, face):
        """Returns (student_info | None, cosine_similarity)."""
        if not self._enrolled_faces:
            return None, 0.0
        q = self.embed(face)
        best_id, best_sim = None, -1.0
        for sid, enc in self._enrolled_faces.items():
            sim = float(np.dot(q, enc))
            if sim > best_sim:
                best_id, best_sim = sid, sim
        if best_id is not None and best_sim >= FACE_MATCH_THRESHOLD and best_id in self._student_info:
            return self._student_info[best_id], best_sim
        return None, best_sim

    # ---------------------------------------------------------------- liveness
    def process_liveness(self, session_id, face):
        """
        Lightweight anti-photo check for the browser/webcam flow: the face must show
        natural head/pose movement across several frames (nose position relative to
        the eyes changes). This stops a perfectly still printed photo but is NOT a
        substitute for a depth/IR sensor - a moving photo can still fool it.
        """
        now = time.time()
        for sid in [k for k, v in self._liveness_sessions.items() if now - v['t'] > 60]:
            del self._liveness_sessions[sid]

        lm = face['landmarks']
        eye_mid = (lm[0] + lm[1]) / 2.0
        eye_dist = max(float(np.linalg.norm(lm[0] - lm[1])), 1.0)
        pose = (lm[2] - eye_mid) / eye_dist  # nose offset, scale invariant

        s = self._liveness_sessions.setdefault(session_id, {'poses': [], 't': now, 'live': False})
        s['t'] = now
        s['poses'].append(pose)
        s['poses'] = s['poses'][-15:]
        if len(s['poses']) >= 4:
            arr = np.array(s['poses'])
            if float(np.ptp(arr[:, 0])) > 0.04 or float(np.ptp(arr[:, 1])) > 0.04:
                s['live'] = True
        return {'is_live': s['live'], 'frames': len(s['poses'])}


face_engine = FaceEngine()
