import csv
import io
import os
from datetime import datetime, timedelta
import pandas as pd
from database import get_db_connection
from config import REPORTS_FOLDER

def get_report_data(report_type='daily', target_date=None, class_name='all', student_id=None):
    """
    Retrieves and structures attendance data according to the selected report type and filters.
    """
    conn = get_db_connection()
    today_str = datetime.now().strftime('%Y-%m-%d')
    if not target_date:
        target_date = today_str

    target_dt = datetime.strptime(target_date, '%Y-%m-%d').date()

    if report_type == 'daily':
        query = """
            SELECT a.attendance_id, a.student_id, a.student_name, a.date, a.time,
                   a.class, a.status, a.method, a.temperature,
                   s.roll_no, s.gender, s.parent_phone
            FROM Attendance a
            JOIN Students s ON a.student_id = s.student_id
            WHERE a.date = ?
        """
        params = [target_date]
        if class_name and class_name.lower() != 'all':
            query += " AND a.class = ?"
            params.append(class_name)
        query += " ORDER BY a.class ASC, s.roll_no ASC"
        df = pd.read_sql_query(query, conn, params=params)

    elif report_type == 'weekly':
        week_start = target_dt - timedelta(days=6)
        query = """
            SELECT a.student_id, a.student_name, a.class,
                   COUNT(CASE WHEN a.status = 'Present' THEN 1 END) as present_days,
                   COUNT(CASE WHEN a.status = 'Absent' THEN 1 END) as absent_days,
                   COUNT(a.attendance_id) as total_working_days,
                   s.parent_phone, s.roll_no
            FROM Attendance a
            JOIN Students s ON a.student_id = s.student_id
            WHERE a.date >= ? AND a.date <= ?
        """
        params = [week_start.strftime('%Y-%m-%d'), target_date]
        if class_name and class_name.lower() != 'all':
            query += " AND a.class = ?"
            params.append(class_name)
        query += " GROUP BY a.student_id, a.student_name, a.class ORDER BY a.class ASC, s.roll_no ASC"
        df = pd.read_sql_query(query, conn, params=params)
        if not df.empty:
            df['attendance_pct'] = (df['present_days'] / df['total_working_days'] * 100).round(1)

    elif report_type == 'monthly':
        # 30 days window up to target date
        month_start = target_dt - timedelta(days=29)
        query = """
            SELECT a.student_id, a.student_name, a.class,
                   COUNT(CASE WHEN a.status = 'Present' THEN 1 END) as present_days,
                   COUNT(CASE WHEN a.status = 'Absent' THEN 1 END) as absent_days,
                   COUNT(a.attendance_id) as total_working_days,
                   s.parent_phone, s.roll_no
            FROM Attendance a
            JOIN Students s ON a.student_id = s.student_id
            WHERE a.date >= ? AND a.date <= ?
        """
        params = [month_start.strftime('%Y-%m-%d'), target_date]
        if class_name and class_name.lower() != 'all':
            query += " AND a.class = ?"
            params.append(class_name)
        query += " GROUP BY a.student_id, a.student_name, a.class ORDER BY a.class ASC, s.roll_no ASC"
        df = pd.read_sql_query(query, conn, params=params)
        if not df.empty:
            df['attendance_pct'] = (df['present_days'] / df['total_working_days'] * 100).round(1)

    elif report_type == 'student':
        query = """
            SELECT a.attendance_id, a.student_id, a.student_name, a.date, a.time,
                   a.class, a.status, a.method, a.temperature,
                   s.roll_no, s.gender, s.parent_phone
            FROM Attendance a
            JOIN Students s ON a.student_id = s.student_id
            WHERE 1=1
        """
        params = []
        if student_id:
            query += " AND a.student_id = ?"
            params.append(student_id)
        query += " ORDER BY a.date DESC"
        df = pd.read_sql_query(query, conn, params=params)

    elif report_type == 'classwise':
        query = """
            SELECT a.class,
                   COUNT(DISTINCT a.student_id) as enrolled_students,
                   COUNT(CASE WHEN a.status = 'Present' THEN 1 END) as total_present,
                   COUNT(CASE WHEN a.status = 'Absent' THEN 1 END) as total_absent,
                   COUNT(a.attendance_id) as total_records
            FROM Attendance a
            WHERE a.date = ?
            GROUP BY a.class
            ORDER BY a.class ASC
        """
        df = pd.read_sql_query(query, conn, params=[target_date])
        if not df.empty:
            df['attendance_pct'] = (df['total_present'] / (df['total_present'] + df['total_absent']) * 100).round(1)

    elif report_type == 'present_list':
        query = """
            SELECT a.student_id, a.student_name, a.class, a.time, a.method, a.temperature, s.roll_no, s.parent_phone
            FROM Attendance a
            JOIN Students s ON a.student_id = s.student_id
            WHERE a.date = ? AND a.status = 'Present'
        """
        params = [target_date]
        if class_name and class_name.lower() != 'all':
            query += " AND a.class = ?"
            params.append(class_name)
        query += " ORDER BY a.class ASC, s.roll_no ASC"
        df = pd.read_sql_query(query, conn, params=params)

    elif report_type == 'absent_list':
        query = """
            SELECT a.student_id, a.student_name, a.class, s.roll_no, s.parent_phone, s.gender
            FROM Attendance a
            JOIN Students s ON a.student_id = s.student_id
            WHERE a.date = ? AND a.status = 'Absent'
        """
        params = [target_date]
        if class_name and class_name.lower() != 'all':
            query += " AND a.class = ?"
            params.append(class_name)
        query += " ORDER BY a.class ASC, s.roll_no ASC"
        df = pd.read_sql_query(query, conn, params=params)

    else:
        df = pd.DataFrame()

    conn.close()
    return df

def generate_csv_report(report_type, target_date, class_name, student_id=None):
    """Exports the specified report to a CSV string."""
    df = get_report_data(report_type, target_date, class_name, student_id)
    if df.empty:
        return "No records found for the selected criteria."
    return df.to_csv(index=False)

def get_low_attendance_students(threshold=75.0, days=30):
    """
    Identifies all students whose attendance is below the threshold (default 75%)
    over the given period (default 30 days).
    """
    conn = get_db_connection()
    start_date = (datetime.now().date() - timedelta(days=days)).strftime('%Y-%m-%d')
    query = """
        SELECT s.student_id, s.name, s.class_name, s.section, s.roll_no,
               s.parent_phone, s.photo_path,
               COUNT(a.attendance_id) as total_working_days,
               COUNT(CASE WHEN a.status = 'Present' THEN 1 END) as present_days,
               COUNT(CASE WHEN a.status = 'Absent' THEN 1 END) as absent_days
        FROM Students s
        JOIN Attendance a ON s.student_id = a.student_id
        WHERE a.date >= ?
        GROUP BY s.student_id, s.name, s.class_name, s.section, s.roll_no, s.parent_phone, s.photo_path
    """
    df = pd.read_sql_query(query, conn, params=[start_date])
    conn.close()

    if df.empty:
        return []

    df['attendance_pct'] = (df['present_days'] / df['total_working_days'] * 100).round(1)
    low_df = df[df['attendance_pct'] < threshold].sort_values(by='attendance_pct', ascending=True)
    return low_df.to_dict(orient='records')

