/**
 * Attendance Reports & Export Client - ShikshaSetu
 */

let currentReportData = [];

document.addEventListener('DOMContentLoaded', () => {
  setupReportControls();
  generateReport();
});

function setupReportControls() {
  const typeSelect = document.getElementById('reportTypeSelect');
  const classCol = document.getElementById('classSelectCol');
  const studentCol = document.getElementById('studentSelectCol');

  typeSelect?.addEventListener('change', () => {
    const val = typeSelect.value;
    if (val === 'student') {
      classCol.classList.add('d-none');
      studentCol.classList.remove('d-none');
    } else {
      classCol.classList.remove('d-none');
      studentCol.classList.add('d-none');
    }
    generateReport();
  });

  document.getElementById('generateReportBtn')?.addEventListener('click', generateReport);

  // CSV Export
  document.getElementById('exportCsvBtn')?.addEventListener('click', () => {
    const type = document.getElementById('reportTypeSelect').value;
    const date = document.getElementById('reportDateInput').value;
    const cls = document.getElementById('reportClassSelect').value;
    const sid = document.getElementById('reportStudentSelect').value;
    window.location.href = `/api/reports/export/csv?type=${type}&date=${date}&class=${encodeURIComponent(cls)}&student_id=${sid}`;
    showToast("Generating CSV report download...", "info");
  });

  // PDF / Print Export
  document.getElementById('exportPdfBtn')?.addEventListener('click', () => {
    const type = document.getElementById('reportTypeSelect').value;
    const date = document.getElementById('reportDateInput').value;
    const cls = document.getElementById('reportClassSelect').value;
    const sid = document.getElementById('reportStudentSelect').value;
    window.open(`/reports/print?type=${type}&date=${date}&class=${encodeURIComponent(cls)}&student_id=${sid}`, '_blank');
  });
}

function generateReport() {
  const type = document.getElementById('reportTypeSelect').value;
  const date = document.getElementById('reportDateInput').value;
  const cls = document.getElementById('reportClassSelect').value;
  const sid = document.getElementById('reportStudentSelect').value;

  const tbody = document.getElementById('reportTableBody');
  tbody.innerHTML = `
    <tr>
      <td colspan="7" class="text-center py-4 text-muted">
        <div class="spinner-border text-primary spinner-border-sm me-2" role="status"></div>
        Compiling ${type} attendance register...
      </td>
    </tr>
  `;

  fetch(`/api/reports/data?type=${type}&date=${date}&class=${encodeURIComponent(cls)}&student_id=${sid}`)
    .then(r => r.json())
    .then(res => {
      if (res.success) {
        currentReportData = res.records;
        renderReportTable(type, currentReportData);
        updateKpis(type, currentReportData);
      }
    })
    .catch(err => {
      console.error(err);
      tbody.innerHTML = `<tr><td colspan="7" class="text-center text-danger py-4">Failed to fetch report data.</td></tr>`;
    });
}

function renderReportTable(type, records) {
  const thead = document.getElementById('reportTableHead');
  const tbody = document.getElementById('reportTableBody');
  const title = document.getElementById('reportTableTitle');
  const countBadge = document.getElementById('reportCountBadge');

  countBadge.textContent = `${records.length} Records`;

  if (type === 'daily') {
    title.textContent = `Daily Attendance Report (${document.getElementById('reportDateInput').value})`;
    thead.innerHTML = `
      <tr>
        <th>Roll No</th>
        <th>Student Name</th>
        <th>Student ID</th>
        <th>Class</th>
        <th>Recorded Time</th>
        <th>Method</th>
        <th>Status</th>
      </tr>
    `;
    tbody.innerHTML = records.map(r => `
      <tr>
        <td>#${r.roll_no}</td>
        <td><strong>${r.student_name}</strong></td>
        <td><code>${r.student_id}</code></td>
        <td><span class="badge bg-light text-dark border">${r.class}</span></td>
        <td>${r.time}</td>
        <td><span class="badge ${r.method === 'Automatic' ? 'badge-method-auto' : 'badge-method-manual'}">${r.method}</span></td>
        <td><span class="badge ${r.status === 'Present' ? 'badge-present' : 'badge-absent'}">${r.status}</span></td>
      </tr>
    `).join('') || emptyRow(7);

  } else if (type === 'weekly' || type === 'monthly') {
    title.textContent = `${type === 'weekly' ? 'Weekly' : 'Monthly'} Cumulative Summary`;
    thead.innerHTML = `
      <tr>
        <th>Roll No</th>
        <th>Student Name</th>
        <th>Class</th>
        <th>Present Days</th>
        <th>Absent Days</th>
        <th>Working Days</th>
        <th>Attendance %</th>
      </tr>
    `;
    tbody.innerHTML = records.map(r => `
      <tr>
        <td>#${r.roll_no}</td>
        <td><strong>${r.student_name}</strong></td>
        <td><span class="badge bg-light text-dark border">${r.class}</span></td>
        <td><span class="fw-bold text-success">${r.present_days}</span></td>
        <td><span class="fw-bold text-danger">${r.absent_days}</span></td>
        <td>${r.total_working_days}</td>
        <td>
          <span class="badge ${r.attendance_pct < 75 ? 'bg-danger' : (r.attendance_pct < 85 ? 'bg-warning text-dark' : 'bg-success')} fw-bold">
            ${r.attendance_pct}%
          </span>
        </td>
      </tr>
    `).join('') || emptyRow(7);

  } else if (type === 'classwise') {
    title.textContent = `Class-wise Attendance Analysis`;
    thead.innerHTML = `
      <tr>
        <th>Class & Section</th>
        <th>Enrolled Students</th>
        <th>Total Present</th>
        <th>Total Absent</th>
        <th>Class Attendance %</th>
      </tr>
    `;
    tbody.innerHTML = records.map(r => `
      <tr>
        <td><strong>${r.class}</strong></td>
        <td>${r.enrolled_students}</td>
        <td><span class="badge badge-present">${r.total_present}</span></td>
        <td><span class="badge badge-absent">${r.total_absent}</span></td>
        <td><span class="badge bg-primary fs-6">${r.attendance_pct}%</span></td>
      </tr>
    `).join('') || emptyRow(5);

  } else if (type === 'student') {
    title.textContent = `Individual Student Attendance History`;
    thead.innerHTML = `
      <tr>
        <th>Date</th>
        <th>Time</th>
        <th>Method</th>
        <th>Temperature</th>
        <th>Status</th>
      </tr>
    `;
    tbody.innerHTML = records.map(r => `
      <tr>
        <td>${r.date}</td>
        <td>${r.time}</td>
        <td><span class="badge ${r.method === 'Automatic' ? 'badge-method-auto' : 'badge-method-manual'}">${r.method}</span></td>
        <td>${r.temperature || 98.4}°F</td>
        <td><span class="badge ${r.status === 'Present' ? 'badge-present' : 'badge-absent'}">${r.status}</span></td>
      </tr>
    `).join('') || emptyRow(5);

  } else {
    // Present List or Absent List
    const isPresent = type === 'present_list';
    title.textContent = isPresent ? 'Students Marked Present Today' : 'Students Marked Absent Today';
    thead.innerHTML = `
      <tr>
        <th>Roll No</th>
        <th>Student Name</th>
        <th>Student ID</th>
        <th>Class</th>
        <th>Parent Phone</th>
        <th>Status</th>
      </tr>
    `;
    tbody.innerHTML = records.map(r => `
      <tr>
        <td>#${r.roll_no}</td>
        <td><strong>${r.student_name}</strong></td>
        <td><code>${r.student_id}</code></td>
        <td><span class="badge bg-light text-dark border">${r.class}</span></td>
        <td>+91 ${r.parent_phone}</td>
        <td><span class="badge ${isPresent ? 'badge-present' : 'badge-absent'}">${isPresent ? 'Present' : 'Absent'}</span></td>
      </tr>
    `).join('') || emptyRow(6);
  }
}

function emptyRow(cols) {
  return `<tr><td colspan="${cols}" class="text-center py-4 text-muted">No attendance records found for this criteria.</td></tr>`;
}

function updateKpis(type, records) {
  const totalEl = document.getElementById('kpiTotalRecords');
  const presEl = document.getElementById('kpiPresentCount');
  const absEl = document.getElementById('kpiAbsentCount');
  const rateEl = document.getElementById('kpiAttendanceRate');

  totalEl.textContent = records.length;

  if (type === 'daily' || type === 'student') {
    const p = records.filter(r => r.status === 'Present').length;
    const a = records.filter(r => r.status === 'Absent').length;
    presEl.textContent = p;
    absEl.textContent = a;
    rateEl.textContent = records.length > 0 ? `${Math.round((p / records.length) * 100)}%` : '0%';
  } else if (type === 'weekly' || type === 'monthly') {
    let totP = 0, totA = 0;
    records.forEach(r => {
      totP += (r.present_days || 0);
      totA += (r.absent_days || 0);
    });
    presEl.textContent = totP;
    absEl.textContent = totA;
    const totDays = totP + totA;
    rateEl.textContent = totDays > 0 ? `${Math.round((totP / totDays) * 100)}%` : '0%';
  } else if (type === 'present_list') {
    presEl.textContent = records.length;
    absEl.textContent = 0;
    rateEl.textContent = '100%';
  } else if (type === 'absent_list') {
    presEl.textContent = 0;
    absEl.textContent = records.length;
    rateEl.textContent = '0%';
  } else if (type === 'classwise') {
    let totP = 0, totA = 0;
    records.forEach(r => {
      totP += (r.total_present || 0);
      totA += (r.total_absent || 0);
    });
    presEl.textContent = totP;
    absEl.textContent = totA;
    rateEl.textContent = (totP + totA) > 0 ? `${Math.round((totP / (totP + totA)) * 100)}%` : '0%';
  }
}

