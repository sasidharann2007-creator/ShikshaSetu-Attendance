import os

AVATAR_DIR = os.path.join(os.path.dirname(__file__), 'static', 'uploads', 'students')
os.makedirs(AVATAR_DIR, exist_ok=True)

COLORS = [
    ('#4F46E5', '#818CF8'), ('#0891B2', '#38BDF8'), ('#059669', '#34D399'),
    ('#D97706', '#FBBF24'), ('#DC2626', '#F87171'), ('#7C3AED', '#A78BFA'),
    ('#DB2777', '#F472B6'), ('#2563EB', '#60A5FA'), ('#0D9488', '#2DD4BF'),
    ('#EA580C', '#FB923C')
]

def generate_svg_avatar(filename, name, index):
    initials = "".join([part[0] for part in name.split()[:2]]).upper()
    c1, c2 = COLORS[index % len(COLORS)]
    
    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="120" height="120">
  <defs>
    <linearGradient id="grad_{index}" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="{c1}" />
      <stop offset="100%" stop-color="{c2}" />
    </linearGradient>
  </defs>
  <rect width="120" height="120" rx="60" fill="url(#grad_{index})" />
  <circle cx="60" cy="48" r="22" fill="#FFFFFF" opacity="0.9" />
  <path d="M 28 100 C 28 78, 92 78, 92 100 Z" fill="#FFFFFF" opacity="0.9" />
  <text x="60" y="55" font-family="Arial, sans-serif" font-size="16" font-weight="bold" fill="{c1}" text-anchor="middle">{initials}</text>
</svg>'''
    filepath = os.path.join(AVATAR_DIR, filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(svg)

if __name__ == '__main__':
    from database import get_db_connection
    conn = get_db_connection()
    students = conn.execute('SELECT student_id, name, photo_path FROM Students').fetchall()
    for idx, s in enumerate(students):
        photo_filename = s['photo_path']
        if not photo_filename.endswith('.svg'):
            # Convert to svg filename
            base = photo_filename.rsplit('.', 1)[0]
            svg_filename = f"{base}.svg"
            conn.execute('UPDATE Students SET photo_path = ? WHERE student_id = ?', (svg_filename, s['student_id']))
            generate_svg_avatar(svg_filename, s['name'], idx)
        else:
            generate_svg_avatar(photo_filename, s['name'], idx)
    conn.commit()
    conn.close()
    print("Generated SVG avatars for all students.")

