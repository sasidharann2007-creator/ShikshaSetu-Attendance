/**
 * Main Global Application Script - ShikshaSetu Rural Smart Attendance
 */

// 1. Audio Buzzer Synthesizer via Web Audio API
class AudioBuzzerSimulator {
  constructor() {
    this.audioCtx = null;
    this.soundEnabled = true;
  }

  init() {
    if (!this.audioCtx) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (AudioContext) {
        this.audioCtx = new AudioContext();
      }
    }
  }

  playSuccessChime() {
    if (!this.soundEnabled) return;
    this.init();
    if (!this.audioCtx) return;

    const ctx = this.audioCtx;
    if (ctx.state === 'suspended') ctx.resume();

    // Two pleasant upward tones (E5 -> G5)
    const now = ctx.currentTime;
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();

    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(659.25, now); // E5
    osc1.frequency.setValueAtTime(783.99, now + 0.12); // G5

    gain1.gain.setValueAtTime(0.3, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

    osc1.connect(gain1);
    gain1.connect(ctx.destination);

    osc1.start(now);
    osc1.stop(now + 0.42);
  }

  playWarningBeep() {
    if (!this.soundEnabled) return;
    this.init();
    if (!this.audioCtx) return;

    const ctx = this.audioCtx;
    if (ctx.state === 'suspended') ctx.resume();

    // 2 quick warning pulses (Duplicate alert)
    const now = ctx.currentTime;
    [0, 0.18].forEach(offset => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(880, now + offset);
      gain.gain.setValueAtTime(0.35, now + offset);
      gain.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.12);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + offset);
      osc.stop(now + offset + 0.14);
    });
  }

  playErrorBuzzer() {
    if (!this.soundEnabled) return;
    this.init();
    if (!this.audioCtx) return;

    const ctx = this.audioCtx;
    if (ctx.state === 'suspended') ctx.resume();

    // Low flat error buzz (Spoof / Unrecognized)
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(320, now);
    osc.frequency.linearRampToValueAtTime(260, now + 0.35);

    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.45);
  }
}

const buzzerSimulator = new AudioBuzzerSimulator();

// 2. Global Toast Notification Helper
function showToast(message, type = 'success') {
  const toastEl = document.getElementById('liveToast');
  const toastMsg = document.getElementById('toastMessage');
  if (!toastEl || !toastMsg) return;

  toastEl.classList.remove('bg-success', 'bg-danger', 'bg-warning', 'bg-info', 'bg-primary');
  
  let icon = 'bi-check-circle-fill';
  if (type === 'success') {
    toastEl.classList.add('bg-success');
    icon = 'bi-check-circle-fill';
  } else if (type === 'danger' || type === 'error') {
    toastEl.classList.add('bg-danger');
    icon = 'bi-x-circle-fill';
  } else if (type === 'warning') {
    toastEl.classList.add('bg-warning');
    icon = 'bi-exclamation-triangle-fill';
  } else {
    toastEl.classList.add('bg-primary');
    icon = 'bi-info-circle-fill';
  }

  toastMsg.innerHTML = `<i class="bi ${icon} fs-5"></i><span>${message}</span>`;
  const toast = new bootstrap.Toast(toastEl, { delay: 4000 });
  toast.show();
}

// 3. Document Ready Initialization
document.addEventListener('DOMContentLoaded', () => {
  // Live Clock
  const clockEl = document.getElementById('liveClockDisplay');
  if (clockEl) {
    const updateClock = () => {
      const now = new Date();
      clockEl.textContent = now.toLocaleDateString('en-IN', {
        weekday: 'short', month: 'short', day: 'numeric',
        hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true
      });
    };
    updateClock();
    setInterval(updateClock, 1000);
  }

  // Sidebar Toggle for Mobile
  const sidebarToggle = document.getElementById('sidebarToggle');
  const sidebar = document.getElementById('sidebar');
  if (sidebarToggle && sidebar) {
    sidebarToggle.addEventListener('click', () => {
      sidebar.classList.toggle('show');
    });
  }

  // Audio Buzzer Toggle
  const soundBtn = document.getElementById('soundToggleBtn');
  const soundIcon = document.getElementById('soundToggleIcon');
  if (soundBtn && soundIcon) {
    soundBtn.addEventListener('click', () => {
      buzzerSimulator.soundEnabled = !buzzerSimulator.soundEnabled;
      if (buzzerSimulator.soundEnabled) {
        soundIcon.className = 'bi bi-volume-up-fill text-primary';
        buzzerSimulator.playSuccessChime();
        showToast('Hardware Audio Buzzer simulation enabled', 'info');
      } else {
        soundIcon.className = 'bi bi-volume-mute-fill text-muted';
        showToast('Hardware Audio Buzzer muted', 'info');
      }
    });
  }
});

