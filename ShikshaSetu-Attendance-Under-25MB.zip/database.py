import sqlite3
import os
import random
from datetime import datetime, timedelta
from config import DATABASE_PATH, UPLOAD_FOLDER

BOY_NAMES = [
    'Aarav', 'Vihaan', 'Reyansh', 'Arjun', 'Ishaan', 'Rohan', 'Deepak', 'Rahul', 'Amit', 'Sunil',
    'Manish', 'Vikas', 'Suresh', 'Mohit', 'Alok', 'Gaurav', 'Rakesh', 'Aryan', 'Vivaan', 'Kabir',
    'Aditya', 'Sai', 'Aniket', 'Harshit', 'Nikhil', 'Pranav', 'Yash', 'Kunal', 'Dev', 'Tanishq',
    'Ritik', 'Om', 'Parth', 'Ayush', 'Varun', 'Shivam', 'Sameer', 'Mayank', 'Kartik', 'Akash',
    'Chirag', 'Tanmay', 'Siddharth', 'Naveen', 'Girish', 'Bhuvan', 'Harish', 'Tarun', 'Lalit', 'Abhinav'
]

GIRL_NAMES = [
    'Pooja', 'Kavya', 'Ananya', 'Sneha', 'Divya', 'Priya', 'Ritu', 'Jyoti', 'Neha', 'Suman',
    'Rani', 'Archana', 'Mamata', 'Bhavna', 'Diya', 'Saanvi', 'Aadhya', 'Kiara', 'Isha', 'Tanvi',
    'Riya', 'Anika', 'Avani', 'Meera', 'Shreya', 'Kriti', 'Payal', 'Swati', 'Simran', 'Tanya',
    'Khushi', 'Sakshi', 'Muskan', 'Komal', 'Aarti', 'Mansi', 'Vidhi', 'Pallavi', 'Rashi', 'Preeti',
    'Garima', 'Nidhi', 'Shilpa', 'Deepika', 'Kajal', 'Monika', 'Sunita', 'Rekha', 'Geeta', 'Sangeeta'
]

SURNAMES = [
    'Sharma', 'Patel', 'Kumar', 'Singh', 'Verma', 'Devi', 'Gupta', 'Yadav', 'Mandal', 'Mehra',
    'Meena', 'Thakur', 'Das', 'Oraon', 'Rawat', 'Jha', 'Tiwari', 'Pandey', 'Sahu', 'Murmu',
    'Kispotta', 'Roy', 'Soren', 'Hansda', 'Joshi', 'Reddy', 'Rao', 'Nair', 'Pillai', 'Mishra',
    'Tripathi', 'Agarwal', 'Choudhary', 'Dubey', 'Sen', 'Mukherjee', 'Banerjee', 'Ghosh', 'Paul', 'Bose'
]

COLORS = [
    ('#4F46E5', '#818CF8'), ('#0891B2', '#38BDF8'), ('#059669', '#34D399'),
    ('#D97706', '#FBBF24'), ('#DC2626', '#F87171'), ('#7C3AED', '#A78BFA'),
    ('#DB2777', '#F472B6'), ('#2563EB', '#60A5FA'), ('#0D9488', '#2DD4BF'),
    ('#EA580C', '#FB923C')
]

def generate_svg_avatar(filename, name, index):
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    initials = "".join([part[0] for part in name.split()[:2]]).upper()
    c1, c2 = COLORS[index % len(COLORS)]
    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="120" height="120">
  <defs>
    <linearGradient id="grad_{index}" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="{c1}" />
      <stop offset="100%" stop-color="{c2}" />
    </linearGradient>
  </defs>
  <rect width="120" height="120" rx="60" fill="url(#grad_{index})" />
  <circle cx="60" cy="48" r="22" fill="#FFFFFF" opacity="0.9" />
  <path d="M 28 100 C 28 78, 92 78, 92 100 Z" fill="#FFFFFF" opacity="0.9" />
  <text x="60" y="55" font-family="Arial, sans-serif" font-size="16" font-weight="bold" fill="{c1}" text-anchor="middle">{initials}</text>
</svg>'''
    filepath = os.path.join(UPLOAD_FOLDER, filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(svg)

def get_db_connection():
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()

    # 1. Classes Table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS Classes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        class_name TEXT NOT NULL,
        section TEXT NOT NULL,
        room_number TEXT,
        class_teacher_name TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(class_name, section)
    )
    ''')

    # 2. Teachers Table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS Teachers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        teacher_id TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        email TEXT UNIQUE,
        phone TEXT,
        subject TEXT,
        assigned_class TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    ''')

    # 3. Students Table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS Students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        class_name TEXT NOT NULL,
        section TEXT NOT NULL,
        roll_no INTEGER NOT NULL,
        gender TEXT NOT NULL,
        parent_phone TEXT NOT NULL,
        photo_path TEXT,
        face_encoding TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    ''')

    # 4. Attendance Table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS Attendance (
        attendance_id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id TEXT NOT NULL,
        student_name TEXT NOT NULL,
        date TEXT NOT NULL,
        time TEXT NOT NULL,
        class TEXT NOT NULL,
        status TEXT NOT NULL CHECK(status IN ('Present', 'Absent')),
        method TEXT NOT NULL CHECK(method IN ('Automatic', 'Manual')),
        temperature REAL DEFAULT 98.4,
        remarks TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(student_id, date),
        FOREIGN KEY (student_id) REFERENCES Students(student_id) ON DELETE CASCADE
    )
    ''')

    # 5. Admin Table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS Admin (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        full_name TEXT NOT NULL,
        role TEXT DEFAULT 'Principal',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    ''')

    conn.commit()
    conn.close()

def seed_sample_data(force=False):
    conn = get_db_connection()
    cursor = conn.cursor()

    # Check if already seeded with all 12 classes
    cursor.execute('SELECT COUNT(DISTINCT class_name) as cnt FROM Classes')
    existing_classes = cursor.fetchone()['cnt']
    cursor.execute('SELECT COUNT(*) as cnt FROM Students')
    existing_students = cursor.fetchone()['cnt']

    if not force and existing_classes >= 12 and existing_students >= 360:
        conn.close()
        return

    # Clear tables for fresh re-seed if force or incomplete
    if force or existing_classes < 12:
        cursor.execute("DELETE FROM Attendance")
        cursor.execute("DELETE FROM Students")
        cursor.execute("DELETE FROM Teachers")
        cursor.execute("DELETE FROM Classes")

    # Seed Admin
    cursor.execute('''
    INSERT OR IGNORE INTO Admin (username, password_hash, full_name, role)
    VALUES ('admin', 'admin123', 'Headmaster Ramesh Sharma', 'Principal')
    ''')

    # 1. Seed Classes 1 to 12 (Standards 1 to 12)
    classes_data = [
        ('Class 1', 'A', 'Room 101', 'Mrs. Anjali Sharma'),
        ('Class 2', 'A', 'Room 102', 'Mr. Suresh Patel'),
        ('Class 3', 'A', 'Room 103', 'Mrs. Geeta Rao'),
        ('Class 4', 'A', 'Room 104', 'Mr. Ramesh Joshi'),
        ('Class 5', 'A', 'Room 105', 'Mrs. Kavita Reddy'),
        ('Class 6', 'A', 'Room 201', 'Mrs. Sunita Devi'),
        ('Class 7', 'A', 'Room 202', 'Mr. Anil Kumar'),
        ('Class 8', 'A', 'Room 203', 'Mrs. Meena Kumari'),
        ('Class 9', 'A', 'Room 204', 'Mr. Vikram Singh'),
        ('Class 10', 'A', 'Room 301', 'Mr. Rajesh Verma'),
        ('Class 11', 'A', 'Room 302', 'Dr. Arvind Mishra'),
        ('Class 12', 'A', 'Room 303', 'Dr. Shweta Mukherjee')
    ]
    cursor.executemany('''
    INSERT OR IGNORE INTO Classes (class_name, section, room_number, class_teacher_name)
    VALUES (?, ?, ?, ?)
    ''', classes_data)

    # 2. Seed Teachers
    teachers_data = [
        ('TCH-101', 'Mrs. Anjali Sharma', 'anjali@ruralschool.edu.in', '9876501001', 'Primary English & EVS', 'Class 1-A'),
        ('TCH-102', 'Mr. Suresh Patel', 'suresh@ruralschool.edu.in', '9876501002', 'Mathematics & Hindi', 'Class 2-A'),
        ('TCH-103', 'Mrs. Geeta Rao', 'geeta@ruralschool.edu.in', '9876501003', 'Environmental Science & Arts', 'Class 3-A'),
        ('TCH-104', 'Mr. Ramesh Joshi', 'ramesh@ruralschool.edu.in', '9876501004', 'Social Studies & Hindi', 'Class 4-A'),
        ('TCH-105', 'Mrs. Kavita Reddy', 'kavita@ruralschool.edu.in', '9876501005', 'Mathematics & English', 'Class 5-A'),
        ('TCH-106', 'Mrs. Sunita Devi', 'sunita@ruralschool.edu.in', '9876501006', 'Mathematics & Science', 'Class 6-A'),
        ('TCH-107', 'Mr. Anil Kumar', 'anil@ruralschool.edu.in', '9876501007', 'Social Science & Hindi', 'Class 7-A'),
        ('TCH-108', 'Mrs. Meena Kumari', 'meena@ruralschool.edu.in', '9876501008', 'English & Sanskrit', 'Class 8-A'),
        ('TCH-109', 'Mr. Vikram Singh', 'vikram@ruralschool.edu.in', '9876501009', 'Physics & Chemistry', 'Class 9-A'),
        ('TCH-110', 'Mr. Rajesh Verma', 'rajesh@ruralschool.edu.in', '9876501010', 'Mathematics & Computers', 'Class 10-A'),
        ('TCH-111', 'Dr. Arvind Mishra', 'arvind@ruralschool.edu.in', '9876501011', 'Senior Physics & Mathematics', 'Class 11-A'),
        ('TCH-112', 'Dr. Shweta Mukherjee', 'shweta@ruralschool.edu.in', '9876501012', 'Chemistry & Biology', 'Class 12-A'),
        ('TCH-113', 'Ms. Priya Patel', 'priya@ruralschool.edu.in', '9876501013', 'Physical Education & Sports', 'All Classes'),
        ('TCH-114', 'Mr. Manoj Nair', 'manoj@ruralschool.edu.in', '9876501014', 'Computer Science & AI Lab', 'All Classes')
    ]
    cursor.executemany('''
    INSERT OR IGNORE INTO Teachers (teacher_id, name, email, phone, subject, assigned_class)
    VALUES (?, ?, ?, ?, ?, ?)
    ''', teachers_data)

    # 3. Seed Students across Standard 1 to 12 (35 students per class = 420 students total)
    random.seed(12345)  # Reproducible random names
    students_data = []
    student_index = 0

    for std in range(1, 13):
        class_name = f"Class {std}"
        section = "A"
        # Track names used within this class to avoid duplicates
        used_names_in_class = set()

        for roll in range(1, 36):
            student_id = f"STU-{std * 100 + roll}"
            gender = 'Male' if roll % 2 != 0 else 'Female'
            
            # Pick unique random name
            first_pool = BOY_NAMES if gender == 'Male' else GIRL_NAMES
            for _ in range(50):
                first = random.choice(first_pool)
                last = random.choice(SURNAMES)
                full_name = f"{first} {last}"
                if full_name not in used_names_in_class:
                    used_names_in_class.add(full_name)
                    break
            
            phone = f"98234{std:02d}{roll:03d}"
            photo_filename = f"{student_id}.svg"

            # Generate avatar
            generate_svg_avatar(photo_filename, full_name, student_index)
            student_index += 1

            students_data.append((
                student_id, full_name, class_name, section, roll, gender, phone, photo_filename
            ))

    cursor.executemany('''
    INSERT OR IGNORE INTO Students (student_id, name, class_name, section, roll_no, gender, parent_phone, photo_path)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', students_data)

    # 4. Seed Historical Attendance (past 25 school days + today)
    # Give 1 or 2 students in each class low attendance (<75%) so alerts display realistic actionable items
    low_att_ids = set()
    for std in range(1, 13):
        low_att_ids.add(f"STU-{std * 100 + 5}")   # Roll 5
        low_att_ids.add(f"STU-{std * 100 + 19}")  # Roll 19

    today = datetime.now().date()
    attendance_records = []

    for day_offset in range(25, -1, -1):
        record_date = today - timedelta(days=day_offset)
        # Skip Sundays (weekday 6)
        if record_date.weekday() == 6:
            continue

        date_str = record_date.strftime('%Y-%m-%d')
        is_today = (day_offset == 0)

        for stu in students_data:
            s_id, s_name, c_name, sec, r_no, gender, phone, photo = stu
            full_class = f"{c_name}-{sec}"

            # For today: mark approximately 70% of students so remaining ~30% are unmarked and ready for live camera scanning!
            if is_today:
                # Leave rolls > 25 unmarked today for live attendance testing!
                if r_no > 25:
                    continue
                is_present = random.random() < 0.92
            else:
                if s_id in low_att_ids:
                    is_present = random.random() < 0.58  # ~58% attendance (triggers < 75% alert)
                else:
                    is_present = random.random() < 0.90  # ~90% attendance

            status = 'Present' if is_present else 'Absent'
            method = 'Automatic' if random.random() < 0.80 else 'Manual'
            hour = random.randint(8, 9)
            minute = random.randint(10, 55)
            second = random.randint(10, 58)
            time_str = f"{hour:02d}:{minute:02d}:{second:02d}"
            temp = round(random.uniform(97.8, 98.7), 1) if is_present else 0.0

            attendance_records.append((
                s_id, s_name, date_str, time_str, full_class, status, method, temp
            ))

    cursor.executemany('''
    INSERT OR IGNORE INTO Attendance (student_id, student_name, date, time, class, status, method, temperature)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', attendance_records)

    conn.commit()
    conn.close()

if __name__ == '__main__':
    init_db()
    seed_sample_data(force=True)
    print("Database initialized and Standard 1 to 12 sample data seeded successfully.")
