"""
ESP32-CAM Device Simulator (Python)
Simulates a physical ESP32-CAM AI-Thinker microcontroller sending attendance frames
over Wi-Fi to the Flask Backend Server.
"""

import time
import io
import random
import requests
from PIL import Image, ImageDraw

SERVER_URL = "http://127.0.0.1:5000/api/esp32/attendance"

def generate_simulated_face_jpeg(student_name="Aarav Kumar"):
    """Generates a synthetic camera frame mimicking the OV2640 camera sensor."""
    img = Image.new('RGB', (320, 240), color=(30, 41, 59))
    draw = ImageDraw.Draw(img)

    # Face Oval
    draw.ellipse([110, 50, 210, 170], fill=(245, 210, 185), outline=(200, 160, 140), width=2)
    # Hair
    draw.arc([110, 40, 210, 120], 180, 360, fill=(40, 30, 20), width=15)
    # Eyes
    draw.ellipse([135, 95, 147, 107], fill=(30, 30, 30))
    draw.ellipse([173, 95, 185, 107], fill=(30, 30, 30))
    # Smile
    draw.arc([140, 120, 180, 150], 20, 160, fill=(180, 60, 60), width=3)
    # School Uniform
    draw.polygon([(80, 240), (160, 180), (240, 240)], fill=(59, 130, 246))

    buf = io.BytesIO()
    img.save(buf, format='JPEG', quality=85)
    return buf.getvalue()

def run_simulation(iterations=3, interval=4):
    print("=================================================================")
    print(" ESP32-CAM Hardware Simulator (AI-Thinker OV2640)")
    print(f" Target Server: {SERVER_URL}")
    print("=================================================================")

    for i in range(1, iterations + 1):
        print(f"\n[ESP32-CAM] Capture Trigger #{i} (PIR Motion / Button Triggered)...")
        jpeg_bytes = generate_simulated_face_jpeg()
        body_temp = round(random.uniform(97.8, 98.6), 1)

        headers = {
            'Content-Type': 'image/jpeg',
            'X-ESP32-Device-ID': 'ESP32-CAM-RURAL-01',
            'X-API-Key': 'change-me-esp32-key',  # must match ESP32_API_KEY
            'X-Body-Temperature': str(body_temp)
        }

        try:
            start_t = time.time()
            response = requests.post(SERVER_URL, data=jpeg_bytes, headers=headers, timeout=5)
            elapsed_ms = int((time.time() - start_t) * 1000)

            print(f"[ESP32-CAM] Server HTTP {response.status_code} ({elapsed_ms}ms)")
            data = response.json()
            print(f"[ESP32-CAM] Payload Response: {data}")

            if data.get('success'):
                print(f" >>> [HARDWARE ACTION] GPIO 13 (GREEN LED): HIGH (ON)")
                print(f" >>> [HARDWARE ACTION] GPIO 14 (BUZZER): Play Success Chime (1800Hz -> 2400Hz)")
                print(f" >>> [ATTENDANCE] Recorded: {data.get('student_name')} ({data.get('student_id')})")
            elif data.get('alert') == 'duplicate':
                print(f" >>> [HARDWARE ACTION] GPIO 15 (RED LED): HIGH (ON)")
                print(f" >>> [HARDWARE ACTION] GPIO 14 (BUZZER): Play Warning Beep-Beep (880Hz)")
                print(f" >>> [DUPLICATE] Attendance already logged earlier today!")
            else:
                print(f" >>> [HARDWARE ACTION] GPIO 15 (RED LED): HIGH (ON)")
                print(f" >>> [HARDWARE ACTION] GPIO 14 (BUZZER): Play Error Alarm")
                print(f" >>> [FAILED] Face not recognized or liveness rejected.")

        except requests.exceptions.ConnectionError:
            print("[ESP32-CAM] ERROR: Could not connect to Flask server. Make sure 'python app.py' is running!")
            break
        except Exception as e:
            print(f"[ESP32-CAM] ERROR: {e}")

        if i < iterations:
            print(f"[ESP32-CAM] Waiting {interval} seconds before next student scan...")
            time.sleep(interval)

    print("\n[ESP32-CAM] Simulation complete.")

if __name__ == '__main__':
    run_simulation()

