import csv
import io
import datetime
from collections import defaultdict, Counter

NA = None
NaT = None

class Index:
    def __init__(self, data=None):
        self.data = list(data) if data is not None else []

    def __iter__(self):
        return iter(self.data)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]

class Series:
    def __init__(self, data, name=None):
        self.data = list(data)
        self.name = name

    def __iter__(self):
        return iter(self.data)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]

    def __add__(self, other):
        if isinstance(other, Series):
            return Series([(a or 0) + (b or 0) for a, b in zip(self.data, other.data)])
        return Series([(a or 0) + other for a in self.data])

    def __sub__(self, other):
        if isinstance(other, Series):
            return Series([(a or 0) - (b or 0) for a, b in zip(self.data, other.data)])
        return Series([(a or 0) - other for a in self.data])

    def __mul__(self, other):
        if isinstance(other, Series):
            return Series([(a or 0) * (b or 0) for a, b in zip(self.data, other.data)])
        return Series([(a or 0) * other for a in self.data])

    def __truediv__(self, other):
        if isinstance(other, Series):
            res = []
            for a, b in zip(self.data, other.data):
                res.append((a / b) if b else 0.0)
            return Series(res)
        return Series([(a / other) if other else 0.0 for a in self.data])

    def __eq__(self, other):
        return Series([x == other for x in self.data])

    def __ne__(self, other):
        return Series([x != other for x in self.data])

    def __ge__(self, other):
        return Series([x >= other if x is not None else False for x in self.data])

    def __gt__(self, other):
        return Series([x > other if x is not None else False for x in self.data])

    def __le__(self, other):
        return Series([x <= other if x is not None else False for x in self.data])

    def __lt__(self, other):
        return Series([x < other if x is not None else False for x in self.data])

    def __and__(self, other):
        return Series([bool(a and b) for a, b in zip(self.data, other)])

    def __or__(self, other):
        return Series([bool(a or b) for a, b in zip(self.data, other)])

    @property
    def str(self):
        return SeriesStringAccessor(self.data)

    def value_counts(self):
        c = Counter(self.data)
        return dict(c)

    def round(self, decimals=1):
        return Series([round(float(x), decimals) if x is not None else 0 for x in self.data], name=self.name)

    @property
    def dt(self):
        return SeriesDateAccessor(self.data)

class SeriesStringAccessor:
    def __init__(self, data):
        self.data = data

    def lower(self):
        return Series([str(x).lower() if x is not None else '' for x in self.data])

    def upper(self):
        return Series([str(x).upper() if x is not None else '' for x in self.data])

class SeriesDateAccessor:
    def __init__(self, data):
        self.data = data

    @property
    def date(self):
        res = []
        for d in self.data:
            if isinstance(d, datetime.datetime):
                res.append(d.date())
            elif isinstance(d, datetime.date):
                res.append(d)
            elif isinstance(d, str):
                try:
                    res.append(datetime.datetime.strptime(d.split(' ')[0], '%Y-%m-%d').date())
                except Exception:
                    res.append(None)
            else:
                res.append(None)
        return Series(res)

class GroupBy:
    def __init__(self, df, by):
        self.df = df
        self.by = [by] if isinstance(by, str) else list(by)

    def size(self):
        counts = defaultdict(int)
        for row in self.df.records:
            if len(self.by) == 1:
                key = row.get(self.by[0])
            else:
                key = tuple(row.get(col) for col in self.by)
            counts[key] += 1
        return GroupByResult(counts, self.by)

class GroupByResult:
    def __init__(self, counts, by):
        self.counts = counts
        self.by = by

    def get(self, key, default=0):
        return self.counts.get(key, default)

    def __getitem__(self, key):
        return self.counts.get(key, 0)

    def items(self):
        return self.counts.items()

    @property
    def index(self):
        return list(self.counts.keys())

    def unstack(self, fill_value=0):
        # Used for df.groupby(['class', 'status']).size().unstack(fill_value=0)
        # by is [col1, col2]
        col1 = self.by[0]
        col2 = self.by[1]

        rows = defaultdict(lambda: defaultdict(int))
        col2_vals = set()

        for (k1, k2), count in self.counts.items():
            rows[k1][k2] = count
            col2_vals.add(k2)

        sorted_rows = sorted(rows.keys())
        result_df_records = []
        for r in sorted_rows:
            entry = {col1: r}
            for c2 in col2_vals:
                entry[c2] = rows[r].get(c2, fill_value)
            result_df_records.append(entry)

        res_df = DataFrame(result_df_records)
        res_df.set_index_col(col1)
        return res_df

class DataFrame:
    def __init__(self, data=None):
        if data is None:
            self.records = []
        elif isinstance(data, list):
            self.records = [dict(r) for r in data]
        elif isinstance(data, dict):
            # dict of lists
            keys = list(data.keys())
            length = len(data[keys[0]]) if keys else 0
            self.records = [{k: data[k][i] for k in keys} for i in range(length)]
        else:
            self.records = []
        self._index_col = None

    @property
    def empty(self):
        return len(self.records) == 0

    @property
    def columns(self):
        if not self.records:
            return []
        return list(self.records[0].keys())

    @property
    def index(self):
        if self._index_col:
            return [r[self._index_col] for r in self.records]
        return list(range(len(self.records)))

    def set_index_col(self, col_name):
        self._index_col = col_name

    def __len__(self):
        return len(self.records)

    def __contains__(self, item):
        return bool(self.records and item in self.records[0])

    def __getitem__(self, key):
        if isinstance(key, str):
            # Return Series
            return Series([r.get(key) for r in self.records], name=key)
        elif isinstance(key, Series) or isinstance(key, list):
            # Boolean indexing mask
            filtered = [r for r, mask in zip(self.records, key) if mask]
            return DataFrame(filtered)
        else:
            raise KeyError(key)

    def __setitem__(self, key, value):
        if isinstance(value, Series):
            val_list = list(value)
        elif isinstance(value, list):
            val_list = value
        else:
            val_list = [value] * len(self.records)

        for i, r in enumerate(self.records):
            r[key] = val_list[i] if i < len(val_list) else None

    def groupby(self, by):
        return GroupBy(self, by)

    def sort_values(self, by, ascending=True):
        sorted_records = sorted(self.records, key=lambda r: (r.get(by) is None, r.get(by)), reverse=not ascending)
        return DataFrame(sorted_records)

    def to_dict(self, orient='records'):
        if orient == 'records':
            return [dict(r) for r in self.records]
        return {col: [r.get(col) for r in self.records] for col in self.columns}

    def to_csv(self, index=False):
        if not self.records:
            return ""
        output = io.StringIO()
        fieldnames = list(self.records[0].keys())
        writer = csv.DictWriter(output, fieldnames=fieldnames)
        writer.writeheader()
        for r in self.records:
            writer.writerow(r)
        return output.getvalue()

def to_datetime(series_or_list):
    res = []
    for item in series_or_list:
        if isinstance(item, (datetime.date, datetime.datetime)):
            res.append(item)
        elif isinstance(item, str):
            try:
                res.append(datetime.datetime.strptime(item.split(' ')[0], '%Y-%m-%d'))
            except Exception:
                res.append(item)
        else:
            res.append(item)
    return Series(res)

def read_sql_query(query, conn, params=None):
    cursor = conn.cursor()
    if params:
        cursor.execute(query, params)
    else:
        cursor.execute(query)
    rows = cursor.fetchall()
    if not rows:
        return DataFrame([])
    
    col_names = [description[0] for description in cursor.description]
    records = []
    for row in rows:
        records.append({col: row[col] for col in col_names})
    return DataFrame(records)
