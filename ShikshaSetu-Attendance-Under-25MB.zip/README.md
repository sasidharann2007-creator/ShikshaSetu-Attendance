# Automated Attendance Management Dashboard for Rural Schools (ShikshaSetu)

A complete, modern, attractive, and robust Automated Attendance Management System designed specifically for rural and semi-urban schools. Features dual-mode attendance (ESP32-CAM / Webcam facial recognition with anti-spoof eye-blink liveness verification & manual teacher register), interactive Python Plotly analytics, SQLite database, low attendance alerts (<75%), and CSV/PDF reports.

---

## 🌟 Key Highlights & Features

1. **Modern Responsive UI / UX**:
   - Bootstrap 5 responsive layout with glassmorphic cards and vibrant color palettes.
   - Comprehensive sidebar navigation with 8 modules: Dashboard, Student Management, Automatic Attendance, Manual Attendance, Analytics & Charts, Reports & Exports, Low Attendance Alerts, and ESP32 Hardware Diagnostics.
   - Live date & time clock with real-time status indicators.

2. **6 Core Dashboard Summary Metric Cards**:
   - 👥 **Total Students**: Total enrolled roster across all classes.
   - ✅ **Present Students**: Real-time count of students present today.
   - ❌ **Absent Students**: Daily absent student count.
   - 📈 **Attendance Percentage**: Live calculated attendance rate (%).
   - 🧑‍🏫 **Total Teachers**: Teaching faculty count.
   - 🏫 **Classes Available**: Active grades and sections.

3. **Student Management**:
   - Add new students with Student ID, Name, Grade & Section, Roll No, Gender, Parent Phone, and Photo.
   - Real-time instant search bar (searches across ID, Name, Phone).
   - Filter by Class and Gender.
   - Interactive Student Profile modal displaying 30-day attendance statistics, visual progress bar, and attendance log.
   - Edit student details and delete students with confirmation prompts.

4. **Dual Attendance Methods (Updating Unified SQLite Database)**:
   - **Method A: Automatic Attendance (ESP32-CAM / Webcam)**:
     - High-speed facial detection and recognition.
     - **Eye-Blink Liveness Verification**: Detects natural eye blinking to prevent static photograph spoofing and proxy attendance.
     - **Strict Duplicate Prevention**: Prohibits marking attendance twice for the same student on the same calendar day.
     - **Hardware Feedback Indicators**:
       - Green LED: Lights ON upon confirmed attendance.
       - Red LED: Lights ON on duplicate / spoof / unrecognized scan.
       - Audio Buzzer: Pleasant upward chime on success, double warning beep on duplicate, and low alarm on spoof.
       - Body Temperature Display: Non-contact thermal reading (e.g. 98.4°F).
   - **Method B: Teacher Manual Attendance**:
     - Grade & Section selector with date picker.
     - Interactive table with Green "Present" / Red "Absent" toggle buttons.
     - One-click bulk actions: "Mark All Present" & "Mark All Absent".
     - Teacher PIN authorization (`1234`) for modifying existing attendance records.

5. **6 Interactive Python Plotly Charts**:
   - 🥧 **Pie Chart**: Present vs Absent student ratio.
   - 📊 **Bar Chart**: Class-wise attendance comparison.
   - 📈 **Line Chart**: Daily attendance trends over time.
   - 📉 **Area Chart**: Monthly attendance percentage trajectory.
   - 🍩 **Donut Chart**: Overall school attendance percentage with center metric.
   - 📊 **Bar Chart**: Student-wise attendance percentage with 75% dashed red target line.
   - **Dynamic Filters**: Today, This Week, This Month, Custom Date Range, and Class & Section.

6. **Attendance Reports & Exports**:
   - Daily, Weekly, Monthly, Individual Student, Class-wise, Present-only, and Absent-only reports.
   - **Download CSV**: Direct CSV file generation.
   - **Print / Save PDF**: Formatted official attendance dossier with header, KPI box, and Class Teacher / Principal signature blocks.

7. **Low Attendance Alert (< 75%)**:
   - Automatically detects students with attendance below the mandatory 75% threshold.
   - Warning banners and critical student table.
   - One-click parent SMS notification modal (pre-filled with guardian notice text).

---

## 🛠️ Technology Stack

- **Frontend**: HTML5, CSS3, JavaScript (ES6+), Bootstrap 5.3, Bootstrap Icons, Plotly.js, Web Audio API.
- **Backend**: Python 3.11, Flask Framework, RESTful JSON API.
- **Database**: SQLite3 (`attendance_system.db`) with Foreign Keys and UNIQUE constraints.
- **Data & Charts**: Python Plotly, Pandas compatibility engine.
- **Computer Vision**: OpenCV, PIL (Pillow), NumPy, Cosine Similarity Face Matching.
- **Hardware**: ESP32-CAM (AI-Thinker), Active Buzzer, Green & Red LEDs, MLX90614 Temperature Sensor.

---

## 🚀 Quick Start Guide

### 1. Start the Flask Backend Server

```bash
python app.py
```

### 2. Access the Web Dashboard

Open your web browser and navigate to:
```
http://127.0.0.1:5000
```

---

## 🔌 ESP32-CAM Hardware Wiring & Flashing

Firmware source code is located in: `hardware/esp32_cam_firmware.ino` and accessible via the **ESP32-CAM Hardware** page on the dashboard.

### Pinout Mapping:
| Component | ESP32-CAM Pin | Description |
|---|---|---|
| **Active Buzzer** | GPIO 14 | PWM / Tone audio chime |
| **Green LED** | GPIO 13 | Success indicator |
| **Red LED** | GPIO 15 | Duplicate / Error indicator |
| **Flash LED** | GPIO 4 | Low-light camera illumination |
| **Trigger Switch / PIR** | GPIO 12 | Scan push button (Active LOW) |
| **Temperature Sensor** | GPIO 2 / I2C | MLX90614 Infrared Temp Sensor |
| **Power** | 5V & GND | Regulated 5V 2A Power Source |

### Flashing via Arduino IDE:
1. Open `hardware/esp32_cam_firmware.ino` in Arduino IDE.
2. Select Board: `AI Thinker ESP32-CAM`.
3. Set your Wi-Fi SSID, Password, and your computer's Flask IP address (`http://<YOUR_IP>:5000/api/esp32/attendance`).
4. Upload and open Serial Monitor at 115200 baud.

