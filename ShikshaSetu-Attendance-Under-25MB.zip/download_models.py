"""Download the OpenCV face detection / recognition ONNX models into ./models."""
import os
import urllib.request

from config import MODEL_DIR

BASE = "https://github.com/opencv/opencv_zoo/raw/main/models"
MODELS = {
    "face_detection_yunet_2023mar.onnx": f"{BASE}/face_detection_yunet/face_detection_yunet_2023mar.onnx",
    "face_recognition_sface_2021dec.onnx": f"{BASE}/face_recognition_sface/face_recognition_sface_2021dec.onnx",
}

for name, url in MODELS.items():
    dest = os.path.join(MODEL_DIR, name)
    if os.path.exists(dest) and os.path.getsize(dest) > 100_000:
        print(f"[skip] {name} already present")
        continue
    print(f"[get ] {name}")
    urllib.request.urlretrieve(url, dest)
    print(f"       saved {os.path.getsize(dest) / 1e6:.1f} MB -> {dest}")
print("Done.")
