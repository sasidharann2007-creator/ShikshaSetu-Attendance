==============================================================
  ShikshaSetu - Automated Attendance System  (START HERE)
==============================================================

WHAT IT DOES
  * A camera (ESP32-CAM) recognises a student's face and marks attendance.
  * The small screen (LCD) shows the name, and the buzzer beeps.
  * A web dashboard shows students, attendance, charts and reports.

--------------------------------------------------------------
STEP 1 - ONE-TIME SETUP (Windows 10 / 11)
--------------------------------------------------------------
  1. Install Python from https://www.python.org/downloads/
     IMPORTANT: on the first installer screen, TICK  "Add Python to PATH".
  2. Right-click this ZIP file -> "Extract All..." and open the folder.
     (Do not run the program from inside the zip.)

--------------------------------------------------------------
STEP 2 - START EVERYTHING WITH ONE CLICK
--------------------------------------------------------------
  Double-click   run_attendance.bat

  The first run installs what it needs (needs internet, a few minutes).
  After that it starts in seconds. It will:
     - start the dashboard,
     - open it in your browser,
     - connect to the camera and start scanning.

  To stop: close the green windows.

  Dashboard address (if the browser does not open):
     http://127.0.0.1:5000

--------------------------------------------------------------
STEP 3 - POWER THE CAMERA BOARD
--------------------------------------------------------------
  * Plug the ESP32-CAM into a USB power source (5V, 2A is best).
  * It creates its own Wi-Fi:
         Name     : ShikshaSetu-CAM
         Password : shiksha123
  * run_attendance.bat joins that Wi-Fi for you. (Your laptop will
    lose internet while connected to it - this is normal.)
  * The LCD shows "WiFi:ShikshaSetu 192.168.4.1" when ready.

--------------------------------------------------------------
STEP 4 - ADD STUDENTS AND THEIR FACES
--------------------------------------------------------------
  1. Dashboard -> "Students" -> add a student.
  2. Click the green CAMERA button on that student's row.
  3. Ask the student to look at the camera. The LCD says
     "Face enrolled" and the board beeps twice.
  4. From now on, when that student looks at the camera:
     LCD shows their name + "Present", two beeps = success,
     three short beeps = already marked today,
     one long beep = face not recognised.

  Tip: good light, face the camera straight, about 40-60 cm away.

--------------------------------------------------------------
WIRING (already done if you got the board assembled)
--------------------------------------------------------------
     ESP32-CAM 5V     -> LCD VCC
     ESP32-CAM GND    -> LCD GND and buzzer (-)
     ESP32-CAM GPIO15 -> LCD SDA
     ESP32-CAM GPIO14 -> LCD SCL
     ESP32-CAM GPIO13 -> buzzer (+)

--------------------------------------------------------------
PROBLEMS? QUICK FIXES
--------------------------------------------------------------
  * "Python is not installed"  -> do Step 1 again (tick Add to PATH).
  * Dashboard says "ESP32-CAM offline"
        -> power the board, then join Wi-Fi "ShikshaSetu-CAM" and
           run run_attendance.bat again.
  * LCD is lit but shows nothing -> turn the small BLUE screw on the
        back of the LCD slowly until text appears.
  * LCD completely dark -> check the 4 wires (5V, GND, SDA, SCL).
  * Page does not open -> check that the green "Dashboard" window
        is still open, then visit http://127.0.0.1:5000
  * "Not recognized" for an enrolled student -> enrol again with
        better light, face straight to the camera.

--------------------------------------------------------------
GOOD TO KNOW
--------------------------------------------------------------
  * Teacher PIN for editing attendance: 1234  (change it in app.py)
  * Camera firmware is already on the board. Only if you replace the
    board: open  hardware\esp32_cam_firmware.ino  in Arduino IDE,
    board "AI Thinker ESP32-CAM", install the "ArduinoJson" library,
    and upload.
  * Your data is stored in the file  attendance_system.db
    (copy it to keep a backup).
